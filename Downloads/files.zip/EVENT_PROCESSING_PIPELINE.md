# Event Processing Pipeline

The flow of an Event from creation through all engines to final presentation.

## High-Level Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                   SOURCES (Ingestion)                           │
├──────────┬──────────┬──────────┬──────────┬──────────┬──────────┤
│ User     │ Calendar │ Bills &  │ Email    │ API &    │ Patterns │
│ Created  │ Import   │ Finance  │ Parser   │ External │ & Rules  │
└────┬─────┴────┬─────┴────┬─────┴────┬─────┴────┬─────┴────┬─────┘
     │          │          │          │          │          │
     └──────────┼──────────┼──────────┼──────────┼──────────┘
                │
                ▼
     ┌──────────────────────┐
     │  EVENT CREATION      │
     │  ────────────────    │
     │  • Validate schema   │
     │  • Assign ID         │
     │  • Set timestamps    │
     │  • status: created   │
     └──────────┬───────────┘
                │
                ▼
     ┌──────────────────────┐
     │  TRUTH GATING        │
     │  ────────────────    │
     │  • Classify claim    │
     │  • Score confidence  │
     │  • Check sources     │
     │  • Permit or gate    │
     └──────────┬───────────┘
                │
           ┌────┴────┐
           │ Fails?  │
           ├─────────┤
      No   │   Yes   │
           ▼         ▼
     ┌─────────┐  ┌──────────┐
     │ Continue│  │ Downgrade│
     │         │  │ or Deny  │
     └────┬────┘  │ confidence
          │       └──────────┘
          │
          ▼
     ┌──────────────────────┐
     │  LIFECYCLE PLACEMENT │
     │  ────────────────    │
     │  • Determine state   │
     │  • Schedule/active?  │
     │  • Validate dates    │
     │  status: scheduled   │
     └──────────┬───────────┘
                │
          ┌─────┴─────┐
     Recurring? │
          ┌─────┴─────┐
      Yes │     No    │
          ▼           ▼
     ┌────────┐  ┌────────────┐
     │Generate│  │Store Single│
     │Children│  │Event       │
     └────┬───┘  └─────┬──────┘
          │            │
          └──────┬─────┘
                 │
                 ▼
     ┌──────────────────────┐
     │  PRIORITY SCORING    │
     │  ────────────────    │
     │  • Compute score     │
     │  • Base + time +     │
     │  • Confidence +      │
     │  • Context + goal    │
     │  priority_score: 0-100
     └──────────┬───────────┘
                │
                ▼
     ┌──────────────────────┐
     │  NOTIFICATION QUEUE  │
     │  ────────────────    │
     │  • Check notify      │
     │  • Schedule alerts   │
     │  • Batch digest      │
     └──────────┬───────────┘
                │
                ▼
     ┌──────────────────────┐
     │  SURFACE RENDERING   │
     │  ────────────────    │
     │  • Priority engine   │
     │  • Voice engine      │
     │  • Pages/widgets     │
     │  • Today, Week, etc. │
     └──────────────────────┘
```

---

## Detailed Pipeline Stages

### Stage 1: Ingestion & Source

**Input:** Raw data from user, system, or external source.

**Process:**
- Identify source type (user input, calendar import, email parse, etc.).
- Extract key fields (date, title, amount, recurrence).
- Normalize to Event schema.

**Examples:**

**User creates reminder:**
```
User input: "Renew car insurance by June 15"
→ Parse: title="Renew car insurance", due_date="2026-06-15"
→ Set: type="reminder", category="personal", source="user_created"
```

**Email parser detects meeting:**
```
Email: "Weekly team sync, Thursdays 2 PM"
→ Parse: title="Weekly team sync", time_of_day="14:00", days=[4]
→ Set: type="appointment", recurrence={pattern: "weekly", days: [4]}
```

**Bill import from finance data:**
```
Transaction: "DUKE ENERGY 06/15 $125.42"
→ Derive: title="Duke Energy", due_date="2026-07-15" (next month)
→ Set: type="financial", financial_impact=-12542, recurrence={pattern: "monthly", day_of_month: 15}
```

**Output:** Partially-normalized Event object ready for validation.

---

### Stage 2: Event Creation & Validation

**Input:** Normalized Event data from ingestion.

**Process:**
1. **Schema validation**: Ensure all required fields are present and type-correct.
2. **Constraint checking**: 
   - Dates are valid (due_date not in past for new Events, unless overdue is intentional).
   - Importance, confidence in 0–1 range.
   - Recurrence rules are well-formed.
3. **Deduplication check**: "Does this Event already exist?" (same date, amount, title).
   - If exists: merge sources, update confidence.
   - If new: generate unique ID and proceed.
4. **ID assignment**: Generate UUID or deterministic ID.
5. **Timestamp assignment**: Set created_at and updated_at.

**Example Success:**
```json
{
  "id": "evt-a1b2c3d4-e5f6...",
  "type": "financial",
  "status": "created",
  "source": "user_created",
  "created_at": "2026-07-08T10:00:00Z",
  "updated_at": "2026-07-08T10:00:00Z",
  "due_date": "2026-07-15",
  "importance": 0.95,
  "confidence": 0.95
}
```

**Example Failure:**
```
Input: due_date = "2020-01-01" (6 years in past)
→ Reject: "Event date is in distant past; likely data error. Confirm?"
```

**Output:** Valid Event object with assigned ID, ready for Truth gating.

---

### Stage 3: Truth Gating & Confidence Scoring

**Input:** Created Event object.

**Process:**

1. **Classification**: Determine the claim type.
   - "Mortgage due March 15" = Fact (user-entered date from source).
   - "You should mow the lawn" = Recommendation (not an Event; rejected).
   - "Lawn probably needs mowing based on growth pattern" = Interpretation (lower confidence).

2. **Confidence assignment** (if not already set):
   - User-entered date → 0.95–1.0.
   - Calendar import → 0.90–0.95.
   - Pattern-detected → 0.70–0.85.
   - AI-suggested → 0.50–0.70.
   - Speculative → 0.30–0.50 or rejected.

3. **Truth-type-specific checks**:
   - **Financial Event**: "Is amount defined?" "Is date verified?" Require high confidence (0.80+) or flag for review.
   - **Health Event**: "Is this from official source (doctor, pharmacy)?" May require 0.90+ confidence.
   - **AI-Suggested Event**: May require 0.60+ confidence minimum to surface.

4. **Conflict detection**: "Does another source claim a different date for the same obligation?"
   - Example: Calendar says "March 15" but email says "March 14" for same appointment.
   - Resolution: Create conflict Event or merge with confidence drop.

5. **Phrasing guidance**: Voice Engine receives confidence level for tone.
   - High confidence (0.95+): "Your mortgage is due March 15."
   - Medium (0.80–0.94): "Your mortgage is likely due March 15."
   - Lower (0.60–0.79): "Your mortgage may be due March 15."

**Example Pass (High Confidence):**
```json
{
  "id": "evt-...",
  "type": "financial",
  "title": "Mortgage payment",
  "due_date": "2026-08-15",
  "confidence": 1.0,
  "source": "user_created",
  "truth_classification": "Fact",
  "truth_clearance": "permitted",
  "phrasing_tone": "factual"
}
```

**Example Pass (Medium Confidence with Caveat):**
```json
{
  "id": "evt-...",
  "type": "suggestion_event",
  "title": "Good day to mow lawn",
  "due_date": "2026-07-14",
  "confidence": 0.68,
  "source": "ai_suggested",
  "truth_classification": "Interpretation",
  "truth_clearance": "permitted_with_caveat",
  "phrasing_tone": "uncertain",
  "metadata": {
    "confidence_reason": "Clear weather + grass growth pattern + free schedule"
  }
}
```

**Example Fail (Insufficient Confidence):**
```
Input Event:
  type: "health"
  title: "You might have anxiety based on your coffee intake"
  confidence: 0.35
  source: "ai_generated"

→ Truth Engine decision: REJECT
→ Reason: "Health Event confidence below floor (0.35 < 0.50). Diagnosis-like claims require medical source."
→ Action: Event archived; not surfaced; available only in search with large caveat.
```

**Output:** Truth-gated Event, optionally with confidence downgrade or denial; phrasing guidance for Voice Engine.

---

### Stage 4: Lifecycle State Placement

**Input:** Truth-gated Event.

**Process:**

1. **Determine starting state:**
   - If `start_date` is in future: `status: "scheduled"`
   - If `due_date` is today or past: `status: "active"` or `"urgent"`
   - If `due_date` is 1–7 days away: `status: "upcoming"`
   - If `due_date` is 7+ days away: `status: "scheduled"`

2. **Handle recurrence:**
   - If `recurrence` is not null, this is a **recurring template**.
     - Mark status as "scheduled" (templates themselves don't surface).
     - Generate child Events for next N occurrences (typically 90 days).
     - Each child is an independent Event with `parent_event_id` set.
   - If no recurrence, store as single Event.

3. **Validate date logic:**
   - If `start_date > due_date`, flag error or swap.
   - If `due_date` is null and `time_sensitivity != "none"`, set a default or warn.

**Example: One-Off Appointment**
```json
Input: {
  "type": "appointment",
  "title": "Dentist appointment",
  "due_date": "2026-07-20",
  "time_of_day": "14:00"
}

Processing:
  current_date = 2026-07-10
  days_until = 10
  → status: "upcoming" (7–30 days out)

Output: {
  "status": "upcoming",
  "parent_event_id": null,
  "child_events": []
}
```

**Example: Recurring Bill**
```json
Input: {
  "type": "financial",
  "title": "Mortgage payment",
  "due_date": "2026-08-15",  // This month's occurrence
  "recurrence": {
    "pattern": "monthly",
    "interval": 1,
    "day_of_month": 15
  }
}

Processing:
  → This is a recurring Event
  → Store template with parent_event_id: null
  → Generate children for next 12 months:
     - evt-mortgage-2026-08-15
     - evt-mortgage-2026-09-15
     - evt-mortgage-2026-10-15
     - ... (12 total)

Output (Template): {
  "status": "scheduled",
  "parent_event_id": null,
  "child_events": ["evt-mortgage-2026-08-15", ..., "evt-mortgage-2026-07-15"]
}

Output (First Child): {
  "id": "evt-mortgage-2026-08-15",
  "status": "upcoming",
  "parent_event_id": "evt-recurring-mortgage",
  "child_events": []
}
```

**Output:** Event with assigned lifecycle state and (if recurring) generated children.

---

### Stage 5: Priority Scoring

**Input:** Lifecycle-placed Event(s).

**Process:**

For each Event:

1. **Compute base components:**
   ```
   base_score = importance × 50
   time_score = compute_time_urgency(due_date, time_sensitivity, status)
   confidence_score = confidence × 20
   context_score = compute_context(user_energy, calendar, money_status)
   goal_score = (goal_connection != null) ? 15 : 0
   life_priority_score = compute_life_priority_alignment(life_priority_rank)
   ```

2. **Combine and clamp:**
   ```
   priority_score = min(100, max(0, 
     base_score + time_score + confidence_score + 
     context_score + goal_score + life_priority_score
   ))
   ```

3. **Apply tie-breaker if equal scores:**
   - State precedence: urgent > active > upcoming > scheduled
   - Due date: earlier wins
   - Creation time: older wins
   - ID: alphabetically

4. **Cache score** for this session (invalidate on state change or next day).

**Example Calculation: Bill Due Tomorrow**
```
Input:
  importance: 0.95
  due_date: 2026-07-09 (tomorrow)
  confidence: 1.0
  status: urgent
  financial_impact: -100.00
  goal_connection: ["savings-goal"]
  life_priority_rank: 1

Computation:
  base_score = 0.95 × 50 = 47.5
  time_score (tomorrow, urgent type) = 28
  confidence_score = 1.0 × 20 = 20
  context_score (money tight) = 5
  goal_score = 15
  life_priority_score (rank 1) = 15
  
  Total: 47.5 + 28 + 20 + 5 + 15 + 15 = 130.5
  Clamped: min(100, 130.5) = 100

Output: priority_score = 100 (highest)
```

**Example Calculation: Routine Habit**
```
Input:
  importance: 0.50
  due_date: 2026-07-14 (5 days away)
  confidence: 0.85
  status: upcoming
  health_impact: 0.6
  goal_connection: ["fitness"]
  life_priority_rank: 3

Computation:
  base_score = 0.50 × 50 = 25
  time_score (5 days, flexible) = 5
  confidence_score = 0.85 × 20 = 17
  context_score (user sedentary) = 5
  goal_score = 15
  life_priority_score (rank 3) = 8
  
  Total: 25 + 5 + 17 + 5 + 15 + 8 = 75

Output: priority_score = 75 (moderate-high)
```

**Output:** Event with computed `priority_score` attached; ready for notification and rendering.

---

### Stage 6: Notification Queue

**Input:** Priority-scored Event.

**Process:**

1. **Check notify strategy:**
   - `notify: "silent"` → No notification; Event is discoverable but quiet.
   - `notify: "digest"` → Add to digest queue (sent once daily or weekly).
   - `notify: "alert"` → Schedule notification at `notify_advance_hours` before due_date.
   - `notify: "priority_alert"` → Schedule for immediate/next refresh check.

2. **Batch similar Events:**
   - Group multiple bills due within 3 days: "3 bills due this week."
   - Group multiple habits into weekly summary: "Gym 3/7 days this week."

3. **Check suppression:**
   - If Event is in `suppress_on_surfaces`, skip notification for those surfaces but keep Event available in search/calendar.

4. **Schedule timing:**
   - For "alert": notification_time = due_date - notify_advance_hours.
   - For "priority_alert": notification_time = current_time (or next refresh).
   - For "digest": notification_time = next digest batch (e.g., 8 AM tomorrow).

5. **Add to queue:**
   - Store notification job with: Event ID, notification time, strategy, user ID.
   - On scheduled time, trigger notification system (Notification Engine).

**Example: Bill Alert Sequence**
```
Event created: 2026-07-08, 10:00 AM
  due_date: 2026-07-15
  notify: "alert"
  notify_advance_hours: 72

Notification scheduling:
  notification_time = 2026-07-15 - 72 hours = 2026-07-12, 3:00 PM
  → Queue notification for 2026-07-12, 3:00 PM

When 2026-07-12, 3:00 PM arrives:
  → Notification system checks queue
  → Finds Event, sends: "Duke Energy bill due in 3 days ($125.42)"
  → User can tap to mark done, defer, snooze, or ignore
```

**Example: Digest Batching**
```
Events created on 2026-07-08:
  1. Gym session (notify: silent)
  2. Bill due 2026-07-12 (notify: digest)
  3. Bill due 2026-07-15 (notify: digest)
  4. Dentist 2026-07-20 (notify: alert)
  5. Mom's birthday 2026-07-16 (notify: digest)

Digest queue (for tomorrow, 8 AM):
  "You have 3 things this week:
   - 2 bills due ($125 + $45)
   - Mom's birthday"

Alert queue (scheduled):
  - Dentist alert: 2026-07-19, 2:00 PM

Silent queue (not queued):
  - Gym sessions remain in calendar only
```

**Output:** Events registered in notification system; ready for delivery.

---

### Stage 7: Surface Rendering

**Input:** Priority-scored, notification-queued Events.

**Process:**

1. **Fetch active/upcoming Events:** Query database for Events matching surface criteria.
   - Today: status="urgent" or "active", due_date=today
   - Week: status in ["upcoming", "active"], due_date in this_week
   - Money: type="financial", sort by priority_score
   - etc.

2. **Sort by priority:**
   ```
   active_events.sort_by(priority_score DESC, due_date ASC, creation_time ASC)
   ```

3. **Select top N for surface:**
   - Today: pick top 1–3 for main note + 1 goal
   - Week: pick top 10–20 for full view
   - Money: pick all bills, sort by due date

4. **Prepare for Voice Engine:**
   - Pass Event + confidence + phrasing_tone to Voice Engine.
   - Voice Engine returns phrased text: "Duke Energy bill is due tomorrow" (high confidence) vs. "Perch suggests your lawn might need mowing" (lower confidence).

5. **Prepare for Design/UI:**
   - Attach highlight_level, color, icon from Event metadata.
   - Pass suppress_on_surfaces to filter which surfaces show this Event.

6. **Render to page:**
   - Today page renders top Event as "one thing" + goal + closing line.
   - Week page renders timeline view.
   - Money page renders sorted bills.
   - Widgets consume rendered data.

**Example: Today Note Rendering**

```
Events after sorting by priority:
  1. Duke Energy bill (due tomorrow) - score: 100
  2. Gym session (flexible, 5 days out) - score: 75
  3. Mom's birthday (milestone, 8 days out) - score: 62

User selections: Show 1 thing + 1 goal

Process:
  → Top Event: Duke Energy bill (ID: evt-..., priority_score: 100)
  → Voice Engine: confidence=1.0 → "Duke Energy bill is due tomorrow."
  → Design: highlight_level="normal", color="neutral"
  → Render to page:

┌─────────────────────────────────┐
│ Perch                        ⚙  │
│                                 │
│ Thursday                        │
│ Money's thin till payday.       │ (Hero line)
│                                 │
│ Duke Energy                     │ (One Thing title)
│ Due tomorrow.                   │ (Phrased by Voice Engine)
│ [Done] [Later]                  │ (Action buttons)
│                                 │
│ Savings Goal                    │ (Top goal)
│ $4,200 → $5,000 (67%)           │
│                                 │
│ Keep it simple.                 │ (Closing line)
└─────────────────────────────────┘
```

**Output:** Rendered Events displayed to user on appropriate surface(s).

---

## Asynchronous Processes

### Notification Delivery (Separate Thread/Timer)

```
Every 5 minutes:
  1. Query perch_notifications table for jobs due in next 5 minutes
  2. For each job:
     a. Fetch Event by ID
     b. Check if still active (not completed/archived)
     c. Render notification message via Voice Engine
     d. Deliver notification (toast, push, email, SMS per user prefs)
     e. Mark notification job as delivered
     f. Log delivery event for analytics
```

### Recurring Event Child Generation (On Load or Daily)

```
On every app load:
  1. Query all recurring Event templates where recurrence != null
  2. For each template:
     a. Find last-generated child's due_date
     b. If < 30 days away, generate next child(ren)
     c. Insert new child Event(s) with parent_event_id set
     d. Add child_event_id to parent's child_events array
```

### Priority Score Recalculation (On Load or Daily)

```
On every app load OR at midnight (whichever first):
  1. Query all active/upcoming Events
  2. For each Event:
     a. Recompute priority_score based on current date/context
     b. Update Event.priority_score in database
  3. Clear old render caches
  4. All surfaces now use fresh scores
```

### Event Archival & Cleanup (Daily or Weekly)

```
Once per day (at 2 AM):
  1. Query all completed Events where completed_at < 30 days ago
  2. Move to perch_events_archive table
  3. Query all expired Events where due_date < 60 days ago
  4. Move to perch_events_archive table
  5. Delete very old archived Events (>2 years)
```

---

## Error Handling & Edge Cases

### Case: Event Created with Date in Past

```
Input Event:
  due_date: 2026-01-01 (6 months ago)
  
Processing:
  → Status placement logic detects: current_date > due_date
  → Decision: Event is overdue
  → Set: status = "urgent", completion_state = "expired"
  → Alert user in Explore Mode: "This event is overdue. Mark as done or reschedule?"
```

### Case: Recurring Event with One Occurrence Missed

```
Template: Monthly bill on day 15
Last child: evt-june-15 (completed)
Today: July 18 (overdue)

Processing:
  → System checks: "Is there an active child for July?"
  → Finds: None. Last known due_date was June 15.
  → Generates: evt-july-15 as missed/overdue child
  → Sets: status = "urgent", completion_state = "expired"
  → Alerts user: "You may have missed a payment. Check."
```

### Case: Event Score Goes to 0 (Not Urgent)

```
Event: Optional suggestion (low importance, low confidence, far in future)
  importance: 0.2
  confidence: 0.5
  days_until: 60
  
Scoring:
  base = 10, time = 1, confidence = 10, others = 0
  total = 21
  
Behavior:
  → Not surfaced in Today or Week
  → Appears in calendar if searched
  → Marked suppress_on_surfaces: ["today_note"]
```

### Case: Two Events with Identical Priority

```
Events:
  1. Bill A (due tomorrow, score: 87)
  2. Bill B (due tomorrow, score: 87)

Tie-breaking (in order):
  1. State: Both "urgent" → tied
  2. Due date: Both tomorrow → tied
  3. Creation time: Bill A created 5 min ago, Bill B just now → Bill A wins
  
Sort result: [Bill A, Bill B]
```

---

## Performance Considerations

### Caching Layers

- **Session cache**: Active/upcoming Events (loaded at app start, invalidated on event change).
- **Computed cache**: priority_score (recomputed once per load or daily).
- **Query result cache**: Frequently accessed queries (TTL: 1 hour or invalidation on event change).

### Query Optimization

- Indexed columns: `due_date`, `status`, `category`, `priority_score`.
- Materialized view `perch_events_active` for fast "what's urgent?" queries.
- Archive table separate from live table (old completed Events don't slow down active queries).

### Batch Operations

- Insert multiple child Events in one transaction (for recurring generation).
- Batch notification jobs into groups (5 bills → 1 digest, not 5 notifications).
- Update priority_scores in bulk query once per load.

---

This pipeline ensures that Events flow predictably from creation through intelligence engines to user-facing surfaces, with Truth gating, priority scoring, and notification batching all integrated seamlessly.
