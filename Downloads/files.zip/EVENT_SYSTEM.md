# Chapter X — Event System

> **Chapter:** Event System (Provisional)
> **Chapter ID:** PERCH-EV
> **Version:** 1.0
> **Status:** Concept — this chapter is a design vision for the layer between Memory and Intelligence
> **Confidence:** 85% — the philosophy and core model are settled; integration depth with future engines is open
> **Owner:** (Design)
> **Implementation:** None (new layer)
> **Depends On:** Truth Engine *(Prototype, should gate all events)*, Priority Engine *(Prototype, consumes events)*, Calendar & Obligations *(Implemented, event source)*, Memory/Brain *(Prototype, event source)*, Money *(Implemented, event source)*, Voice Engine *(Implemented, event consumer)*, Notification System *(Concept)*
> **Last Updated:** (Current)

*The Event System is Perch's bridge between storage and intelligence. Memory holds facts; Events say when facts matter. This chapter describes the taxonomy, lifecycle, scoring model, and integration patterns of a system designed to scale from today's 100 events to millions, through billions of users, without losing the core truth that Perch should understand what deserves attention—and when.*

---

## 1. Purpose

The Event System answers: **when does information matter?**

Memory stores *what is true*. The Truth Engine validates *how strongly we can claim it*. The Priority Engine orders *what rises for attention*. But before any of that machinery engages, the Event System must ask: **does this information even have a when? Is it time-sensitive? Does it change as time passes?**

Events are the atoms of time-bound intelligence. A bill is not an event until a due date makes it urgent. A capture in the Brain is not an event until days have passed and the user should see it again. A goal is not an event until the moment comes to contribute. A weather pattern is not an event until it changes the calculus of what to do today.

**The Event System is where state meets time.**

---

## 2. Vision

Perch should feel less like a task manager and more like an intelligent life operating system that *knows what you're trying to do* and *understands when it matters*.

The Event System is the foundational machinery that enables:

- **Proactive surfacing**: Perch surfaces the right information at the right moment, before the user has to ask.
- **Cross-domain intelligence**: A single event can connect money, calendar, goals, health, family, and property in one unified priority scoring.
- **AI-generated guidance**: The system supports AI creating events from patterns, predictions, and suggestions without flooding the user.
- **Notification philosophy**: Smart batching, context-aware timing, and the discipline to stay silent when silence is wisdom.
- **Automation and delegation**: Future systems can act on events—scheduling, delegating, automating—with full transparency.

**The destination:** a system where every important thing inside Perch eventually becomes an Event, and every Event is understood by every engine in the stack.

---

## 3. Design Philosophy

### 3.1 Events Are Declarative, Not Imperative

An Event describes *what is time-sensitive*, not *what must happen*. A bill due tomorrow is an Event. Whether the user pays it today, tomorrow, or later is a Recommendation or an action—not part of the Event itself. This distinction keeps the Event System honest and simple.

### 3.2 Time Is the Primary Dimension

Events exist in time. Without a date or a recurrence pattern, something is not an Event—it's a Fact, a Goal, or a Belief. The Event System owns everything with a temporal dimension: deadlines, appointments, recurring tasks, anniversaries, trip countdowns, project milestones.

### 3.3 Events Can Exist Without Actions

Not every Event requires the user to *do* something. A weather warning is an Event. An upcoming birthday is an Event. An account reaching a threshold is an Event. Some Events are pure information; some are prompts; some are suggestions. The Priority Engine and Recommendation Engine determine what rises; the Event System simply catalogs what's time-bound.

### 3.4 AI-Generated Events Are First-Class

The system must support both human-created and AI-generated events with equal rigor. A user-entered recurring reminder and a system-suggested "good day to mow the lawn" are both Events, both scored, both subject to Truth-gating. The AI-generated flag is present; the trust is not degraded.

### 3.5 Events Have Confidence

Every Event carries a confidence score, inherited from or computed from its sources. A user-entered bill due date has 1.0 confidence; a predicted weather event has 0.75. The Truth Engine gates which events can surface and at what strength based on this confidence.

### 3.6 Events Are Immutable at Creation

Once an Event is created with an ID, that ID is canonical. Edits create a new state; they do not change the past. This allows event history, audit trails, and proper conflict resolution if two sources disagree about the same obligation.

---

## 4. The Event Object

Every Event in Perch is a unified data structure with the following fields. Not every field is used by every Event type—but every Event *can* have every field.

### 4.1 Identity & Metadata

**`id`** (string, immutable, UUID)
- Unique identifier for this Event instance.
- Generated at creation; never changes.
- Format: `evt-{type}-{timestamp}-{hash}` or standard UUID v4.
- **Purpose:** stable reference for all downstream systems.

**`type`** (enum, required, immutable)
- The category of Event (see §5 for full taxonomy).
- Examples: `reminder`, `deadline`, `appointment`, `bill`, `milestone`.
- **Purpose:** routes to type-specific logic (Recommendation, Notification, Voice).

**`category`** (enum, required, mutable)
- Broad domain classification orthogonal to type.
- Examples: `financial`, `health`, `family`, `work`, `home`, `project`, `learning`.
- **Purpose:** filters and grouping; feeds Priority scoring (e.g., "importance-to-user-by-category").

**`status`** (enum, required, mutable)
- The Event's current state in its lifecycle (see §6).
- Values: `created`, `scheduled`, `active`, `upcoming`, `urgent`, `completed`, `cancelled`, `expired`, `archived`, etc.
- **Purpose:** determines visibility, notification eligibility, and what surfaces where.

**`source`** (enum, required, immutable)
- How this Event came into Perch.
- Examples: `user_created`, `imported_calendar`, `derived_from_bill`, `ai_suggested`, `pattern_detected`, `email_parsed`.
- **Purpose:** feeds Truth Engine confidence gating and provenance tracking.

**`created_at`** (ISO 8601 timestamp, immutable)
- When this Event was first recorded.

**`updated_at`** (ISO 8601 timestamp, mutable)
- When this Event was last modified (any field except `id`, `type`, `source`, `created_at`).

**`user_created`** (boolean, immutable)
- `true` if the user explicitly created this Event.
- `false` if it was derived, imported, or AI-generated.
- **Purpose:** prioritization heuristic; user-created events often carry stronger intent.

**`ai_generated`** (boolean, immutable)
- `true` if an AI system created this Event (suggested a reminder, detected a pattern, predicted a need).
- **Purpose:** Truth-gating; AI events may require higher confidence thresholds to surface.

**`metadata`** (object, mutable)
- Free-form extra fields. Examples: `{"color": "red", "icon": "alert", "urgency_reason": "payday in 2 days"}`.
- **Purpose:** extensibility without schema changes; feeds Voice Engine for personalized phrasing.

**`tags`** (array of strings, mutable)
- User-applied or system-applied labels. Examples: `["high-priority", "recurring", "travel", "health"]`.
- **Purpose:** filtering, grouping, and Life-priority alignment checks.

---

### 4.2 Temporal Dimensions

**`due_date`** (ISO 8601 date or null, mutable)
- The date on which this Event becomes/became urgent or past-due.
- `null` if the Event has no definite due date (a someday goal, a vague reminder).
- **Purpose:** core input to Priority scoring; determines "time-remaining" axes.

**`start_date`** (ISO 8601 date or null, mutable)
- The date on which this Event becomes relevant or "starts counting."
- Examples: a trip starts 2 weeks before the date (alerts on day N); a project milestone activates on this date.
- **Purpose:** gates when an Event becomes active; allows pre-event alerts.

**`end_date`** (ISO 8601 date or null, mutable)
- The date on which this Event is no longer relevant or auto-completes.
- Examples: a return-item deadline, a trip end, a subscription auto-renewal window.
- **Purpose:** defines the Event's window of relevance.

**`all_day`** (boolean, mutable, default false)
- `true` if this Event is not time-of-day specific.
- Examples: birthdays, anniversaries, "clean gutters sometime this month."
- **Purpose:** notification timing; all-day events don't need a precise time alert.

**`time_of_day`** (HH:MM or null, mutable)
- The specific time this Event matters, if applicable.
- Examples: `14:30` for a 2:30 PM appointment, `09:00` for a morning shift.
- **Purpose:** precise notification timing; UI display (Explore Mode calendars).

**`timezone`** (IANA timezone string or null, mutable)
- The timezone in which `time_of_day` should be interpreted.
- `null` → device local time (current Perch default).
- **Purpose:** travel support; future cross-timezone intelligence.

**`recurrence`** (object or null, mutable)
- Structured recurrence rule. Examples: `{pattern: "monthly", interval: 1, day_of_month: 15}`, `{pattern: "weekly", interval: 1, days: [1,3,5]}`.
- Supports basic patterns (daily, weekly, monthly, yearly) and intervals.
- `null` if non-recurring.
- **Purpose:** generates child Events for each occurrence; avoids storing thousands of separate Events.

**`recurrence_end_date`** (ISO 8601 date or null, mutable)
- The date after which this recurrence should stop regenerating.
- `null` → recurs indefinitely.
- **Purpose:** prevents bills from recurring forever after account closure; goals from recurring after completion.

**`recurrence_exceptions`** (array of ISO 8601 dates, mutable)
- Specific dates on which this recurring Event should NOT occur.
- Example: bill recurs monthly except December (holiday).
- **Purpose:** handles one-off overrides without breaking the recurrence rule.

**`time_sensitivity`** (enum, mutable)
- How much time pressure affects this Event's priority.
- Values: `immediate` (minutes to hours), `urgent` (hours to days), `soon` (days to weeks), `flexible` (weeks+), `none` (time-insensitive).
- **Purpose:** feeds Priority scoring; different urgency curves for different Event types.

---

### 4.3 Relationship to User's Life

**`importance`** (0–1 float, mutable, default 0.5)
- How much this Event matters in general, independent of time.
- 1.0 = critical to life goals and well-being (health emergency, major deadline, child's event).
- 0.5 = routine obligation (regular bill, normal appointment).
- 0.0 = nice-to-know but optional (a possible activity, a FYI).
- **Purpose:** feeds Priority scoring; combined with time-sensitivity for final score.

**`priority_score`** (0–100 float, mutable)
- The computed output of the Priority Engine for this Event.
- Recalculated every session based on current context (time remaining, competing demands, user state).
- **Purpose:** enables deterministic ordering across all surfaces; explainability.

**`confidence`** (0–1 float, mutable)
- Confidence that this Event is accurate/will actually happen.
- 1.0 = user-entered fact or definitive source (bill in person's hands, doctor confirmed appointment).
- 0.95 = very reliable (calendar import, automated detection with near-zero false positives).
- 0.75 = somewhat uncertain (pattern-detected recurring event, AI suggestion based on limited data).
- 0.5 = speculative (predicted needs, weather forecast, experimental recommendation).
- **Purpose:** Truth Engine gates which Events surface and at what strength; confidence-weighted against time-remaining.

**`health_impact`** (0–1 float or null, mutable)
- How strongly this Event affects the user's physical or mental health.
- Examples: medication reminder (1.0), exercise goal (0.7), optional wellness activity (0.3).
- `null` = not health-related.
- **Purpose:** Priority scoring input; some users weight health heavily.

**`financial_impact`** (float or null, mutable, in cents)
- The monetary cost or benefit if this Event is acted on or ignored.
- Examples: bill (negative), income (positive), missed-deadline penalty (negative).
- `null` if no financial impact.
- **Purpose:** Priority scoring; money often drives urgency.

**`relationship_impact`** (array of person_ids or null, mutable)
- Which people this Event affects (family members, colleagues, friends).
- Examples: `["person-001", "person-002"]` for a family dinner.
- `null` if no direct relationship impact.
- **Purpose:** Priority scoring; family events get weighted higher for many users.

**`goal_connection`** (array of goal_ids or null, mutable)
- Which Goals this Event contributes to or blocks.
- Examples: "contribute to savings" or "prepare for travel".
- `null` if no goal connection.
- **Purpose:** Priority scoring; goal-aligned events rise.

**`life_priority_rank`** (1–5 int or null, mutable)
- Alignment with the user's stated life priorities (1 = top priority, 5 = lowest).
- Example: if "financial freedom" is rank 1, a bill aligns with rank 1.
- `null` if no clear alignment.
- **Purpose:** Priority scoring tiebreaker; ensures life priorities matter.

---

### 4.4 Status & Completion

**`completion_state`** (enum, mutable)
- The Event's status in its own lifecycle.
- Values: `incomplete`, `completed`, `skipped`, `dismissed`, `snoozed`, `deferred`, `cancelled`, `expired`.
- **Purpose:** determines whether Event is visible, actionable, or archived.

**`completed_at`** (ISO 8601 timestamp or null, mutable)
- When the Event was marked completed.
- `null` if not completed.
- **Purpose:** event history; learning patterns.

**`completion_notes`** (string or null, mutable)
- User's note on why it was completed, skipped, or dismissed.
- **Purpose:** feedback for belief formation; learning user preferences.

**`snoozed_until`** (ISO 8601 timestamp or null, mutable)
- If snoozed, when it should re-surface.
- `null` if not snoozed.
- **Purpose:** temporary suppression without cancellation.

**`deferred_to_date`** (ISO 8601 date or null, mutable)
- If deferred, the new date this Event should be rescheduled to.
- `null` if not deferred.
- **Purpose:** allows moving Events in time without deleting them.

---

### 4.5 Hierarchy & Relationships

**`parent_event_id`** (string UUID or null, immutable)
- If this Event is a child of a recurring Event, the parent's ID.
- `null` if this is a standalone or root recurring Event.
- **Purpose:** traces back from a specific bill occurrence to the recurring "bill template."

**`child_events`** (array of Event IDs, mutable)
- If this is a recurring Event, the IDs of generated child Events.
- **Purpose:** manage updates; if recurring rule changes, update all children.

**`related_event_ids`** (array of Event IDs, mutable)
- IDs of Events that are semantically related but not parent-child.
- Examples: a trip Event linked to travel-prep Events, hotel reservations, flight confirmations.
- **Purpose:** surface related information; compute "this Event is part of a larger moment."

**`related_memory_ids`** (array of memory/capture/brain IDs, mutable)
- IDs of Memory/Brain captures, beliefs, or stored facts relevant to this Event.
- **Purpose:** Explore Mode deep-dive; traceability to source data.

**`related_person_ids`** (array of person IDs, mutable)
- IDs of People entries relevant to this Event.
- Examples: birthday Event links to a person; a meeting Event links to attendees.
- **Purpose:** People page integration; relationship filtering.

---

### 4.6 Notification & Surface Control

**`notify`** (enum, mutable)
- Notification strategy for this Event.
- Values: `silent` (no notification), `digest` (batched), `alert` (immediate), `priority_alert` (interrupt).
- **Purpose:** keeps notification system from becoming noisy; respects user attention budget.

**`notify_advance_hours`** (int or null, mutable)
- If `notify` is not `silent`, how many hours before `due_date` to send the notification.
- Examples: `24` for "tell me a day before", `2` for "tell me two hours before".
- `null` → default per Event type (bills: 3 days; appointments: 1 day; etc.).
- **Purpose:** fine-grained notification timing.

**`suppress_on_surfaces`** (array of surface names, mutable)
- Surface areas where this Event should NOT appear, even if high-priority.
- Examples: `["today_note", "week_view"]` means hide this Event from Today and Week but show on Money page.
- **Purpose:** user control; reduce noise without cancelling Events.

**`highlight_level`** (enum, mutable)
- Visual emphasis when this Event is displayed.
- Values: `minimal`, `normal`, `prominent`, `critical`.
- **Purpose:** UI rendering; helps Voice/Design adapt tone and presentation.

---

## 5. Event Taxonomy

The Event System recognizes 15 canonical Event types, plus an expansion slot for future system Events. Each type has distinct characteristics, default scoring rules, and notification patterns.

### 5.1 Reminder

**What it is:** A time-bound note the user created or Perch suggested—something to remember on a specific date.

**Characteristics:**
- User-driven or AI-suggested; both are first-class.
- May or may not require action.
- Can recur (weekly reminder to plan meals).
- Time-sensitivity ranges from flexible to immediate.

**Example:** "Renew car insurance" due June 15.

**Default fields:**
- `time_sensitivity`: `soon` (typically)
- `importance`: 0.4–0.7
- `notify`: `digest`
- `priority_boost`: based on recency and recurrence

**Future:** Reminders will integrate with the Voice Engine for personalized timing ("tell me reminders on Friday nights, when I plan the week").

---

### 5.2 Deadline

**What it is:** A hard stop—something *must* be done by this date or consequences follow.

**Characteristics:**
- Always has a fixed `due_date`.
- Often creates stress as the date approaches.
- May be recurring (annual license renewal) or one-off.
- High confidence (usually human-entered or externally tracked).

**Example:** "Tax return due April 15."

**Default fields:**
- `time_sensitivity`: `urgent` (as due date approaches)
- `importance`: 0.7–1.0
- `notify`: `priority_alert` (escalates as deadline nears)
- `priority_boost`: strongest boost in final week

**Future:** Deadline intelligence could suggest buffer time ("this takes 4 hours; start 2 days before").

---

### 5.3 Appointment

**What it is:** A scheduled obligation with a specific time and place.

**Characteristics:**
- Always has `due_date`, usually `time_of_day` and possibly `timezone`.
- Often involves other people.
- May have a duration.
- Usually not recurring (but some appointments are: "monthly check-up").

**Examples:** Medical appointment at 2:30 PM, meeting with manager, client call.

**Default fields:**
- `time_sensitivity`: `immediate` (as time approaches)
- `all_day`: `false` (unless otherwise specified)
- `time_of_day`: required or strongly suggested
- `notify`: `alert` (appears in calendar, not digest)
- `related_person_ids`: often populated

**Future:** Calendar app integration; automatic rescheduling if conflicts detected.

---

### 5.4 Maintenance

**What it is:** Periodic upkeep of an asset, property, body, or system.

**Characteristics:**
- Recurring (monthly HVAC filter, annual truck service).
- Time-sensitivity often flexible until delayed several cycles.
- Financial impact (cost to do vs. cost to ignore).
- Declining importance as deadline approaches unless long-overdue.

**Examples:** Change oil, clean gutters, replace air filter, get haircut, renew passport.

**Default fields:**
- `time_sensitivity`: `flexible` initially, escalates to `urgent` if overdue
- `recurrence`: almost always present
- `notify`: `digest` (usually not time-critical)
- `priority_boost`: higher if significantly overdue

**Future:** Maintenance intelligence—"your car is due for service AND you have a 200-mile trip next week; schedule sooner."

---

### 5.5 Financial

**What it is:** Any money-related Event with a date: bills, invoices, income, subscriptions, transfers.

**Characteristics:**
- Nearly always recurring (bills, paychecks, subscriptions).
- High confidence (defined amounts, dates).
- Clear financial impact (negative for bills, positive for income).
- Often linked to account balances (shortage detection).

**Examples:** Mortgage due 15th, paycheck Friday, subscription renewal, tax refund.

**Default fields:**
- `time_sensitivity`: `urgent` (as due date approaches)
- `financial_impact`: always populated (negative or positive)
- `importance`: varies (mortgage: 1.0; streaming service: 0.3)
- `notify`: escalates as due date nears
- `category`: `financial`

**Future:** Income events will link to savings goals; bill timing will coordinate with payday for optimal payment strategy.

---

### 5.6 Habit

**What it is:** A desired behavior pattern—exercise, meditation, reading, habit-building challenges.

**Characteristics:**
- Usually recurring daily or weekly.
- Time-sensitivity is flexible (can be done anytime that day).
- Low consequence for missing one instance; cumulative impact over weeks.
- Often tied to health or personal goals.

**Examples:** "Go to the gym," "Meditate 10 minutes," "Read before bed."

**Default fields:**
- `time_sensitivity`: `flexible`
- `importance`: varies (0.3–0.8 depending on goal weight)
- `notify`: `silent` or `digest` (too frequent to alert)
- `health_impact` or `goal_connection`: usually present

**Future:** Habit intelligence—streak tracking, optimal time suggestions, integration with Belief Engine (learning actual habits vs. aspirational).

---

### 5.7 Goal

**What it is:** A milestone or target within a larger Goal (Chapter 4).

**Characteristics:**
- Linked to a Goal object.
- May have a target date, or may be ongoing ("keep side project moving").
- Lower immediacy than deadlines but high importance.
- Often recurring contribution Events ("contribute $200 this month").

**Examples:** "Save $5000 for trip," "Ship v1 of app," "Read 12 books this year."

**Default fields:**
- `goal_connection`: always populated
- `time_sensitivity`: `soon` or `flexible`
- `importance`: 0.7–1.0 (user's chosen goals)
- `notify`: `digest` or `silent`

**Future:** Goal burndown Events—"you're on track for this goal if you do X this week."

---

### 5.8 Milestone

**What it is:** A marker of progress or change—an Event that signifies something completed, achieved, or transforming.

**Characteristics:**
- Usually one-off or yearly (anniversary, birthday, project completion).
- Time-sensitive only in the sense of "this date is coming."
- Often celebratory or reflective rather than action-driven.
- Low consequence for missing but high relationship/emotional impact.

**Examples:** 5-year wedding anniversary, "One year of homesteading," project launch date.

**Default fields:**
- `importance`: 0.6–1.0 (varies)
- `time_sensitivity`: `soon`
- `notify`: `digest` (surfaced as a positive note, not an alarm)
- `related_person_ids`: often populated (people we celebrate with)

**Future:** Milestone intelligence—"this is your 10-year anniversary with your company; Perch will surface career-reflection prompts."

---

### 5.9 Notification

**What it is:** A system-generated alert or status change that the user should know about.

**Characteristics:**
- AI-generated or system-generated (not user-created).
- Examples: "Your car's registration is expiring," "The package is arriving tomorrow," "Your credit score changed."
- Time-sensitivity varies (expiration warnings: urgent; status updates: flexible).
- May not require action but should be known.

**Examples:** Account alert, delivery notification, status change.

**Default fields:**
- `ai_generated`: almost always `true`
- `user_created`: `false`
- `confidence`: varies (0.6–1.0)
- `notify`: depends on type; many are `silent` (always available, surfaced only if searched)

**Future:** Notification filtering—users can control which system notifications surface vs. become permanently available in search.

---

### 5.10 Alert

**What it is:** A condition that requires immediate attention—an exception or emergency.

**Characteristics:**
- Time-sensitivity is `immediate`.
- High importance.
- Often rare (overdraft alert, medical emergency symptom reminder, security issue).
- Not recurring; each alert is distinct.

**Examples:** "Account overdrawn," "Medication allergy interaction detected," "Breach detected on your account."

**Default fields:**
- `time_sensitivity`: `immediate`
- `importance`: 1.0
- `notify`: `priority_alert` (always)
- `ai_generated` or system-generated
- `highlight_level`: `critical`

**Future:** Alert escalation—if an alert is not acknowledged within an hour, escalate to voice call or SMS.

---

### 5.11 Opportunity

**What it is:** A optional, time-bound chance—a good moment to do something, not an obligation.

**Characteristics:**
- Often AI-suggested ("Tuesday looks clear; great day to mow").
- Time-sensitivity: flexible to soon.
- Importance: 0.3–0.6 (nice but optional).
- Confidence: may be lower (0.5–0.8) if based on predictions or patterns.

**Examples:** "Good weather window for outdoor projects," "You have 4 free hours Thursday," "Your friend is in town."

**Default fields:**
- `ai_generated`: usually `true`
- `importance`: 0.3–0.7
- `confidence`: 0.6–0.85
- `notify`: `digest`
- `time_sensitivity`: `flexible`

**Future:** Opportunity recommendations will pull from Living World, calendar, goals, and weather in concert.

---

### 5.12 Recurring Event

**What it is:** A meta-Event representing a repeating pattern. Individual occurrences are child Events.

**Characteristics:**
- Has a `recurrence` rule.
- Does not itself appear on surfaces (only children do).
- Updating the parent updates all future child Events (unless exceptions).

**Examples:** "Weekly therapy appointment," "Monthly mortgage payment," "Annual car inspection."

**Default fields:**
- `recurrence`: always present and non-null
- `child_events`: populated as instances are generated
- `recurrence_end_date`: may be `null` (infinite) or set

**Implementation detail:** The system distinguishes between the recurring template (one entry) and 52 individual instances (52 child Events). This keeps the event count tractable.

---

### 5.13 Suggested Event

**What it is:** An AI-generated suggestion that the user has not yet confirmed.

**Characteristics:**
- Confidence is lower (0.4–0.7) until user confirms.
- `user_created`: `false`
- `ai_generated`: `true`
- May graduate to a real Event if user accepts, or be dismissed.
- Usually appears in a "suggestions" surface or low in priority.

**Examples:** "Based on patterns, you might want to mow the lawn this weekend," "This project milestone should be mid-June."

**Default fields:**
- `confidence`: 0.4–0.7 (pre-confirmation)
- `completion_state`: `created` or `pending_review`
- `notify`: `silent` (no alarm until confirmed)

**Future:** Suggested Events will have acceptance/rejection buttons that feed the Belief Engine to learn what suggestions the user values.

---

### 5.14 System Event

**What it is:** An internal Perch event—not user-facing unless they explore, but important for system reasoning.

**Characteristics:**
- Examples: "Perch belief about your energy level updated," "Payment method expiring," "Data sync failed."
- Confidence varies (0.6–1.0).
- Usually not surfaced to user but available for diagnostics or deep-exploration.

**Examples:** Belief state change, data integrity issue, sync failure.

**Default fields:**
- `notify`: `silent`
- `user_created`: `false`
- `suppress_on_surfaces`: likely includes all public pages
- `metadata`: contains internal state details

**Future:** System Events will feed a "Perch Health" dashboard for users who want to debug or understand Perch's reasoning.

---

### 5.15 External Event

**What it is:** An Event imported from an external source—calendar, email, API, third-party app.

**Characteristics:**
- `source`: `imported_calendar`, `email_parsed`, `api_ingested`, etc.
- Confidence depends on source (calendar import: 0.95; email-parsed guess: 0.6).
- Immutable at creation (sourced from external system).
- May conflict with other Events if sources disagree.

**Examples:** Event from Google Calendar, bill from email parser, flight confirmation from email.

**Default fields:**
- `source`: always specifies external source
- `confidence`: varies (0.6–0.95)
- `related_memory_ids`: links back to source email/document
- `user_created`: `false`

**Future:** External calendar ingestion (Chapter 13 — Integrations); conflict detection if same bill appears from email and manual entry.

---

### 5.16 Expansion

The taxonomy is designed to expand. New types can be added as Perch grows (example: Travel Events, Health Events with provider details, Insurance Events). The core scoring logic works for all types because it relies on time-sensitivity, importance, confidence, and context—not type-specific rules.

---

## 6. Event Lifecycle

Events move through well-defined states as they age, are acted on, or are superseded. This lifecycle is the backbone of event visibility and processing.

### 6.1 States

**`created`**: The Event has been instantiated but not yet placed in any priority surface or notification queue. It is discoverable but quiet.
- **When:** immediately upon creation.
- **Visibility:** search only, or internal only (for system Events).

**`scheduled`**: The Event has been accepted into the system and is awaiting its moment. It appears in planning surfaces (calendar, agenda).
- **When:** after `created`, once Event is validated and Truth-gated.
- **Visibility:** calendar, planning widgets.

**`active`**: The Event's window of relevance has opened. If it has a `start_date`, it has passed; if it has a `due_date`, we are now within the "active zone" (e.g., 3 days before due, or on due date).
- **When:** `current_date >= start_date` OR `time_remaining <= active_threshold` (e.g., 3 days).
- **Visibility:** Today note, attention surfaces, notifications begin.

**`upcoming`**: The Event is coming soon (within a week, typically). It rises in priority and may be the subject of advance notifications.
- **When:** 7 days or fewer until due date.
- **Visibility:** week-view, Today if high priority, notification prep.

**`urgent`**: The Event is critically near its deadline (within 24–48 hours) or has already begun (an appointment is happening today).
- **When:** 1–2 days until due OR event is occurring right now.
- **Visibility:** prominent in Today, may trigger alert notifications.

**`completed`**: The user has marked this Event done. It moves to history; no longer surfaces unless viewed historically.
- **When:** user clicks Done or system detects completion (bill paid, appointment ended).
- **Visibility:** history archive; contributes to Belief formation.

**`cancelled`**: The Event was explicitly cancelled (appointment rescheduled, subscription cancelled, reminder no longer needed). It does not recur if recurring; it does not reappear.
- **When:** user or system cancels it.
- **Visibility:** archived, but retained for audit trail.

**`expired`**: The Event's window has passed and it was never completed or acted on. For ongoing obligations (bills), expiration triggers creation of the next recurrence. For one-off Events (reminders), expiration means it should have been handled and wasn't—a "missed" signal.
- **When:** `current_date > due_date + grace_period` (grace period varies by type; often 0).
- **Visibility:** archived, but retained for pattern analysis.

**`archived`**: The Event is no longer part of active attention. It is stored for history, search, and belief formation but never surfaces in normal flows.
- **When:** user explicitly archives, or system archives very-old completed/expired Events.
- **Visibility:** search and historical analysis only.

### 6.2 State Transitions & Rules

```
created
  ↓
scheduled (if Truth-gated and valid)
  ↓
active / upcoming (as time passes)
  ↓
urgent (as deadline nears)
  ├→ completed (if user marks Done)
  ├→ cancelled (if user cancels)
  ├→ expired (if deadline passes without action)
  ├→ snoozed (if user snoozes; re-enters active on snooze end)
  └→ deferred (if user reschedules; moves due_date, re-enters scheduled)
  ↓
archived (after time, or explicit user action)
```

**Special transitions:**
- **Snoozed**: The Event is temporarily suppressed but re-enters its normal lifecycle at `snoozed_until` timestamp. Not terminal.
- **Deferred**: The Event's `due_date` is moved; the Event re-enters `scheduled` state with a new date. Not terminal.
- **Recurring child expiration**: If a child Event (from a recurring parent) expires, the parent generates the next child Event on schedule.

### 6.3 State Implications

| State | Surfaces? | Scored? | Notified? | Archived? |
|---|---|---|---|---|
| `created` | No (search only) | No | No | No |
| `scheduled` | Calendar/agenda | Yes | Pre-event alerts only | No |
| `active` | All surfaces | Yes | Yes | No |
| `upcoming` | All surfaces | Yes | Yes | No |
| `urgent` | Prominent (Today) | Yes (high boost) | Yes (escalated) | No |
| `completed` | No | No | No | Auto-archive (after 7d) |
| `cancelled` | No | No | No | Auto-archive |
| `expired` | No | No | No | Auto-archive |
| `archived` | No (search only) | No | No | Yes |

---

## 7. Priority Scoring Model

The Event System feeds the Priority Engine. When an Event is active or upcoming, the Priority Engine computes its `priority_score` (0–100) on demand, every session.

### 7.1 Scoring Formula (Simplified)

```
base_score = importance * 50
time_score = compute_time_urgency(due_date, start_date, time_sensitivity)
confidence_score = confidence * 20  // max +20
context_score = compute_context(user_energy, location, calendar_free_time, money_status)
goal_score = (goal_connection != null) ? 15 : 0
life_priority_score = compute_life_priority_alignment(life_priority_rank)

final_score = base_score + time_score + confidence_score + context_score + goal_score + life_priority_score
clamped_score = min(100, max(0, final_score))

return clamped_score
```

### 7.2 Component Breakdown

**Base Score** (0–50)
- Anchored on `importance`.
- A 1.0 importance = 50 base points.
- A 0.0 importance = 0 base points.
- This ensures truly important Events have a floor even if all other factors are low.

**Time Urgency Score** (0–30)
- Computed from `time_remaining = days_until(due_date)`, `time_sensitivity`, and lifecycle state.
- Exponential curve: as deadline nears, urgency increases non-linearly.
  - 30+ days out: +0–2 points
  - 7–30 days: +2–10 points
  - 1–7 days: +10–25 points
  - Today: +25–30 points
  - Overdue: +30 points immediately (max)
- `time_sensitivity` modulates the curve:
  - `immediate`: sharp curve (hits max early)
  - `urgent`: normal curve
  - `flexible`: flat curve (low urgency until very close)
  - `none`: no time boost (time-insensitive Events)
- State transitions apply boosts: `urgent` state adds +5; `active` state adds +3.

**Confidence Score** (0–20)
- A 1.0 confidence = +20 points.
- A 0.5 confidence = +10 points.
- A 0.0 confidence = 0 points.
- Ensures high-confidence Events rise above speculative ones.
- **Truth Engine implication:** Very low-confidence Events (< 0.3) may be entirely gated off by Truth Engine before scoring.

**Context Score** (0–20, domain-specific)
- Adjustments based on user's current state:
  - User is well-rested & no major calendar conflicts: +5
  - Money is tight & Event is financial: +8
  - Event is health-related & user's health status is declining: +10
  - User has been putting off this Task type for weeks: +5
  - User has blocked time for this category today: +5
- **Implementation note:** This requires Living World / real-time user state. Starting implementation would have many of these as `0`.

**Goal Connection Score** (+15)
- If `goal_connection` is non-null and refers to a top-3 goal: +15
- If `goal_connection` refers to a lower-priority goal: +8
- If no goal connection: +0
- Reinforces that goals move the needle.

**Life Priority Alignment Score** (0–15)
- If `life_priority_rank` matches user's top priority (e.g., "financial freedom"): +15
- If rank 2: +10
- If rank 3: +8
- If rank 4–5 or unaligned: +0–3
- Tiebreaker for same-urgency Events.

### 7.3 Example Scores

**Example 1: Mortgage Payment Due Tomorrow**
- Importance: 1.0 (critical)
- Base: 50
- Time (1 day, urgent): +25
- Confidence (1.0, user-entered date): +20
- Context (money is adequate): 0
- Goal: +8 (financial goal)
- Life priority (financial freedom, rank 1): +15
- **Total: 50 + 25 + 20 + 0 + 8 + 15 = 118 → clamped to 100**

**Example 2: Optional Gym Session This Week**
- Importance: 0.5 (nice, not critical)
- Base: 25
- Time (3 days out, flexible): +5
- Confidence (0.9, user habit): +18
- Context (user has been sedentary): +5
- Goal (health goal): +15
- Life priority (rank 3): +8
- **Total: 25 + 5 + 18 + 5 + 15 + 8 = 76**

**Example 3: AI-Suggested "Good Day to Mow Lawn" (Based on Weather)**
- Importance: 0.4 (routine maintenance)
- Base: 20
- Time (7 days out, flexible): +2
- Confidence (0.6, AI prediction): +12
- Context (clear weather, free time): +8
- Goal (home maintenance): +8
- Life priority (rank 4): +2
- **Total: 20 + 2 + 12 + 8 + 8 + 2 = 52**

### 7.4 Deterministic Tie-Breaking

When two Events have identical or very close scores, the following tie-break order is applied:

1. **User explicitly pinned**: If user has pinned an Event to the top, it wins (not yet implemented but designed).
2. **State precedence**: `urgent` > `active` > `upcoming` > `scheduled`.
3. **Due date**: Earlier due date wins (sort by `daysUntil` ascending).
4. **Creation time**: Older Event wins (stability; doesn't flip-flop between sessions).
5. **Stable ID sort**: If all else equal, alphabetical ID (ensures determinism).

### 7.5 Recalculation & Caching

- **Recalculated every session** (every time the user opens Perch or refreshes).
- **Not recalculated continuously** (to avoid UI jitter and expensive computation).
- Scores are **cached per session**, not persisted.
- When `important` mutable fields change (`due_date`, `importance`, `confidence`, `status`), cache is invalidated for that Event.

---

## 8. Truth Gating & Confidence

Every Event must pass the Truth Engine before surfacing.

### 8.1 Truth Engine Rules for Events

**Rule 1: Confidence Floor by Event Type**
- `deadline` or `appointment`: min 0.8 confidence to surface prominently. Below 0.8, show with caveat ("uncertain date").
- `bill` or `financial`: min 0.9. Below that, flag for review.
- `reminder` or `opportunity`: min 0.5. Below that, show as suggestion only.
- `habit` or `milestone`: min 0.5.
- System Events and Notifications: min 0.6 (internal use allows lower).

**Rule 2: Confidence Sources**
- User-entered or from definitive external source (calendar import, official bill): 0.95–1.0.
- Derived from reliable pattern (user always pays this bill on date X): 0.85–0.95.
- Pattern-detected or AI-suggested: 0.5–0.75.
- Purely speculative or very low signal: 0.0–0.5.

**Rule 3: Phrasing by Confidence**
- 0.95–1.0: "Your mortgage is due March 15." (declarative)
- 0.85–0.94: "Your mortgage is likely due March 15." (likely)
- 0.70–0.84: "Your mortgage may be due March 15." (uncertain)
- 0.50–0.69: "Perch suggests your mortgage might be due around March 15." (speculative)
- Below 0.50: Do not surface to user; keep internal or require explicit user confirmation.

**Rule 4: AI-Generated Events Start Low**
- An AI-suggested Event starts at 0.5–0.65 confidence.
- User acceptance moves it to 0.85+.
- User dismissal → Event is archived; pattern is recorded.

**Rule 5: Disagreement Surfacing**
- If two sources propose conflicting dates for the same Event (e.g., email says March 15, calendar says March 14), the Event shows with both dates and the Truth Engine confidence drops. Example: "Your appointment appears to be March 15 (calendar) or March 14 (email). Confirm, please."

---

## 9. AI-Generated Events

AI systems in Perch may create Events in several ways, all Truth-gated and confidence-scored.

### 9.1 Event Generation Sources

**From Calendar Analysis**
- Detects patterns: "You always have therapy on Tuesdays at 2 PM. Propose recurring Event?"
- Source: `source = "pattern_detected"`, confidence 0.75
- Requires user acceptance to become a full Event.

**From Bill History & Finance Data**
- Detects recurring charges: "You're charged $15.99 monthly on the 1st (Netflix). Shall Perch track this?"
- Source: `source = "derived_from_bank"`, confidence 0.85
- High confidence (derived from actual transactions); often near 1.0 if consistent.

**From Email & Messages**
- Parses: "Meeting Thursday at 3 PM" from calendar invite or email.
- Source: `source = "email_parsed"`, confidence 0.80–0.90 (depends on source clarity).

**From Travel & External APIs**
- Flight confirmations, hotel bookings, reservations.
- Source: `source = "api_ingested"` (e.g., email forward to Perch, booking confirmation).
- Confidence 0.90–0.95 (definitive from provider).

**From Pattern Analysis & Beliefs**
- "You usually mow the lawn every 3 weeks. The lawn is getting long; suggest mowing this weekend?"
- Source: `source = "pattern_detected"`, confidence 0.60–0.75.
- Requires user acceptance.

**From Living World & Weather**
- "Tuesday looks clear and cool—good day to mow before the heat hits."
- Source: `source = "ai_suggested"`, confidence 0.50–0.65.
- Purely advisory; requires explicit user intent to become an Event.

**From Predictions & Trends**
- "Your account balance drops below the comfortable zone around April 10 unless a bill is deferred. Shall Perch alert you?"
- Source: `source = "prediction"`, confidence 0.65–0.80.
- Depends on how stable the prediction is.

**From Project & Goal Analysis**
- "To finish the app by June, you need to ship the API by May 15. Create a milestone?"
- Source: `source = "ai_suggested"`, confidence 0.60–0.75.

### 9.2 AI Event Acceptance & Rejection

AI-suggested Events appear in a **Suggestions surface** (not yet built) or as a low-priority item. The user can:

- **Accept**: Event moves to `scheduled` state, confidence jumps to 0.85–0.90, full lifecycle begins.
- **Reject**: Event is deleted or marked `dismissed`; the rejection is logged as feedback.
- **Modify**: User tweaks date, description, or details; Event is created with user-modified data, confidence 0.90+.
- **Ignore**: Event remains in Suggestions; can appear multiple times or be hidden.

The Belief Engine watches these interactions to learn: **which AI-generated Events does this user value?** Over time, AI suggestions improve.

### 9.3 Avoiding Event Spam

**Rule 1: Confidence Threshold Before Surfacing**
- Never surface an AI-generated Event below 0.45 confidence to the user; keep it searchable only.

**Rule 2: Batching & Digesting**
- AI suggests multiple Events (e.g., 5 detected patterns). Bundle them into one notification: "Perch found 5 patterns you might track. Review?"
- Never send 5 separate notifications.

**Rule 3: Diminishing Returns**
- If the user rejects the same type of suggestion repeatedly (e.g., "mow the lawn" proposals), reduce the frequency and lower the prominence of future suggestions of that type.

**Rule 4: Preference Learning**
- Track: "This user loves AI suggestions for money/savings opportunities but ignores AI suggestions for exercise." Adjust future surfacing accordingly.

---

## 10. Relationships & Integration

Events do not exist in isolation. They connect to every other layer of Perch.

### 10.1 Event ↔ Memory/Brain

- An Event can be `related_memory_ids` to a Brain capture.
- Example: The capture "Renew car insurance" generates a Reminder Event due on the renewal date.
- When an Event is completed, the associated Brain capture may be marked complete or archived.
- **Belief Formation**: Completion of Events feeds the Belief Engine (learning user's actual habits vs. aspirations).

### 10.2 Event ↔ Calendar & Obligations

- Events *are* the Calendar. `PerchEvents.all()` (Chapter 3, §4b) assembles Events from multiple sources.
- The Calendar/Obligations chapter's `PerchDate` and `PerchEvents` functions are the Event System's query layer.
- Events inherit all `PerchDate.intel()` classifications (today, this week, overdue, etc.).

### 10.3 Event ↔ Money

- `financial` Event type is the primary interface to Money (Chapter 2).
- Bill Events: source = bills, category = financial.
- Income Events: positive `financial_impact`.
- Threshold alert Events: "account balance below $500."
- The Priority Engine's `context_score` includes money status: "money tight → financial Events rise."

### 10.4 Event ↔ Goals

- Events can have `goal_connection` to Goals (Chapter 4).
- Example: "Contribute $200 to Emergency Fund" Event links to the Emergency Fund Goal.
- Goal milestones become Milestone Events.
- The Priority Engine weights goal-connected Events higher.

### 10.5 Event ↔ Projects

- Project milestones become Events (Chapter 5).
- Project dependencies create derived Events: "Ship docs by Friday" (blocks "Launch").
- Project Events feed the Recommendation Engine for smart suggestions: "You're blocked on the dashboard; want to work on tests instead?"

### 10.6 Event ↔ People & Relationships

- Events can have `related_person_ids`.
- Birthdays, anniversaries, recurring calls with people are Events.
- The Relationship Engine (future) can derive Events from relationships: "It's been 3 weeks since you talked to Mom; call her?"
- Delegated Events (future) will track things owed *to* others.

### 10.7 Event ↔ Living World & Weather

- Weather Events (future): "Snow expected Wednesday" becomes an Event that affects outdoor Event priority.
- Location Events (future): "You're in Denver; the skiing is good" or "Package arriving at home."
- The Context Score in Priority Scoring uses Living World state (if available).

### 10.8 Event ↔ Priority Engine

- Events are the **primary input** to the Priority Engine.
- Priority Engine computes `priority_score` for each active/upcoming Event every session.
- Top-scored Events surface on Today, Money, Week, etc.

### 10.9 Event ↔ Recommendation Engine

- Recommendation Engine consumes high-priority Events.
- Example: High-priority "Good weather" Opportunity + high-priority "Mow lawn" Reminder → Recommendation: "Tuesday looks perfect for mowing."
- Not all Events are Recommendations; high-priority Events become candidates for Recommendations (Chapter 9).

### 10.10 Event ↔ Voice Engine

- Voice Engine phrases top-scored Events.
- Same Event, different voice tones: "Duke Energy bill is due tomorrow" (factual) vs. "Money's tight till payday" (empathetic).
- Voice rules (Chapter 11) apply to Event presentation.

### 10.11 Event ↔ Notification System

- Event.`notify` setting controls notification strategy.
- `notify_advance_hours` controls timing.
- Notification Engine batches Events by type and user preference.

---

## 11. Notification Philosophy

Events alone don't serve the user if they arrive as 47 interruptions a day. The Notification System is where the Event System learns restraint.

### 11.1 Core Principles

- **Silence is wisdom**: Perch should often be quiet, letting the user open Perch on their own rhythm.
- **Attention is a budget**: Every notification spends user attention; budget must be guarded.
- **Context matters**: A notification at 6 AM is different from one at midnight.
- **Type defines rhythm**: Bills use a different notification pattern than daily habits.

### 11.2 Notification Strategies

**Silent Reminders** (`notify = "silent"`)
- No notification sent.
- Event is discoverable in calendar, search, widgets.
- User opens Perch and finds it on Today or calendar.
- **Best for:** recurring habits, low-consequence reminders, optional opportunities.
- **Examples:** Gym sessions, weekly planning, optional chores.

**Digest Notification** (`notify = "digest"`)
- Events are bundled and sent once daily or once weekly.
- Example: "You have 5 things coming up: gym Thursday, mom's birthday Saturday, car service due, project review Friday..."
- **Timing:** Once per day (morning) or once per week (Monday morning).
- **Best for:** reminders, routine obligations, low-urgency items.
- **Examples:** Recurring bills, maintenance tasks, habit tracking.

**Alert Notification** (`notify = "alert"`)
- Sent at a specific time before the Event (e.g., 24 hours before, or 2 hours before an appointment).
- Example: "Mortgage due tomorrow."
- **Timing:** Configurable per Event or per type; default varies (bills: 3 days before; appointments: 1 day before).
- **Best for:** actionable Events requiring user response—bills, appointments, deadlines.
- **Examples:** Bills, appointments, project deadlines.

**Priority Alert** (`notify = "priority_alert"`)
- Sent immediately when an Event enters `urgent` state or if overdue.
- Example: "Your power bill is overdue by 2 days."
- **Timing:** Real-time (or checked every 15 minutes).
- **Best for:** critical Events, emergency conditions, overdue obligations.
- **Examples:** Overdue bills, urgent health reminders, account alerts.

### 11.3 Smart Batching

Multiple Events of the same type in a time window are batched:

- **Bills batch:** If three bills are due within 3 days, one digest: "3 bills due this week: Duke Energy, Internet, Mortgage. Total: $1200."
- **Appointments batch:** If two appointments are scheduled the same day, one reminder 2 hours before: "Two appointments today: 2 PM therapy, 6 PM yoga."
- **Habit batch:** Daily habit reminders are silent; weekly summary digest: "You hit the gym 3/7 days; meditation 2/7 days."

### 11.4 Context-Aware Timing

- **User's active hours**: Notifications arrive during known wake times; avoid 11 PM unless critical.
- **Calendar-aware**: No notification if user is already in a related appointment.
- **Money-aware**: Billing reminders increase in frequency as deadline nears.
- **Goal-aware**: Goal contribution reminders align with user's stated goal timeline.

### 11.5 Notification Suppression

User can:

- **Suppress by type:** "No daily habit reminders; show only missed goals."
- **Suppress by surface:** "Never notify about optional items; only bills and appointments."
- **Suppress by time:** "No notifications between 6 PM and 8 AM."
- **Suppress by category:** "Silent on financial reminders this week; I'm focused on health."

---

## 12. Widget Consumption of Event Data

Events are the atoms of information; Widgets are the molecules—higher-level views built from Events.

### 12.1 Today Widget

**Consumes:** Top-scored Event (usually) + context.
- Displays: One opening line + one actionable item + one goal sentence.
- Event state feed: Today's `active` and `urgent` Events.
- Priority input: Event `priority_score` determines what becomes the "one thing."

### 12.2 Week Widget

**Consumes:** All Events for current week (`isThisWeek` = true).
- Displays: Timeline of upcoming Events by day, grouped by type (appointments, bills, goals, habits).
- Event states: `upcoming` and `active`.
- Grouping: Calendar view, chronological, possibly grouped by category.

### 12.3 This Month Widget

**Consumes:** All Events for current month (`isThisMonth` = true).
- Displays: Calendar grid with Events marked.
- Event states: `scheduled`, `upcoming`, `active`.
- Density visualization: Days with many Events marked differently.

### 12.4 Bills Widget

**Consumes:** All `financial` Events filtered by `category = "financial"`.
- Displays: Ordered list of upcoming bills, total due this month, due next payday.
- Event fields: amount, due date, account, status.
- Priority: Ordered by Event `priority_score`.

### 12.5 Travel Countdown Widget

**Consumes:** Events tagged `travel` or `category = "travel"` + related events.
- Displays: Trip start date, countdown, checklist of related prep Events.
- Event relationships: Uses `related_event_ids` to surface related prep tasks.

### 12.6 Work/Shifts Widget

**Consumes:** All `appointment` Events for `category = "work"`.
- Displays: Upcoming shifts, on-call patterns, certification expirations.
- Recurrence handling: Shows next 8 weeks of recurring shifts.

### 12.7 Health Widget

**Consumes:** Events with `health_impact > 0` or `category = "health"`.
- Displays: Medication reminders, appointments, health goals, metrics trending.

### 12.8 Projects Widget

**Consumes:** Milestone Events (`type = "milestone"`) linked to Projects + deadline Events.
- Displays: Project progress, upcoming milestones, blocked tasks.

### 12.9 Weather/Context Widget

**Consumes:** Weather Events (future) + opportunity Events.
- Displays: Current/upcoming weather, suggested opportunities based on conditions.

### 12.10 Living World Widget

**Consumes:** Ambient Events (optional activities, weather, location).
- Displays: Static or gently animated world preview that shifts based on upcoming Events.

---

## 13. Performance, Caching & Scaling

The Event System must support millions of Events across millions of users. Here is the scalability strategy.

### 13.1 Caching Strategy

**Session Cache** (in-memory, per user)
- Loaded at app startup, invalidated on explicit event creation/update.
- Contains: All active, upcoming, scheduled Events for the next 90 days.
- Size for user with 100 events: ~2 MB (acceptable).
- Size for power user with 1000 events: ~20 MB (acceptable).

**Computed Cache**
- `priority_score` is computed on-demand, cached per session.
- Invalidated when time passes (every day at midnight) or when Event state changes.
- Example: scores computed once at session start; Today uses that cache until refresh or event change.

**Query Result Cache**
- Results of frequent queries (`getToday()`, `getThisWeek()`, `getUpcoming(7)`) are cached.
- TTL: 1 hour or invalidated on event change.

### 13.2 Archiving & Cleanup

**Archive completed/expired Events after 30 days**
- Completed Events move to archive after 30 days (user can change this).
- Archived Events are searchable but not loaded into session cache.
- Archive storage is separate from live storage (fast lookup for live, slower but searchable for archived).

**Old archived Events (>1 year) move to cold storage**
- Still queryable via search but not loaded into normal cache.
- Belief Engine can still access for long-term pattern analysis.

**Recurring Event optimization**
- Store the recurrence rule once; generate child Events on-demand for a rolling 90-day window.
- Example: "Monthly mortgage" rule generates 12 child Events (next 12 months) at load time.
- Oldest completed child can be pruned; new child generated as needed.

### 13.3 Indexing

**Primary Indexes**
- `due_date` (sorted, enables range queries by date)
- `status` (filtered queries: "all active Events")
- `category` (filtered queries: "all financial Events")
- `user_id` (basic multi-tenancy)
- `priority_score` (sorted, for "top 5 Events today")

**Secondary Indexes (lazy)
- `goal_connection` (for "which Events affect this Goal?")
- `related_person_ids` (for "which Events involve this person?")
- `tags` (for filtering by user-applied tags)

**Full-text Index** (if implemented)
- On `title`, `description`, `metadata` for search.

### 13.4 Synchronization & Offline

**Sync Strategy**
- Changes to Events are queued locally; synced to backend when network available.
- Conflict resolution: Last-write-wins for mutable fields; immutable fields never conflict.
- Recurring rule edits: Mark all future child Events as dirty; re-sync on next load.

**Offline Support**
- Cached Events remain visible and functional offline.
- User can create, edit Events offline; they sync when online.
- No network-dependent queries during offline mode (no fresh Priority scores; use cached).

### 13.5 Scaling Roadmap

| Scale | Challenge | Solution |
|---|---|---|
| **100 events** (single user) | None | Naive in-memory object. |
| **1,000 events** (power user) | Cache size, query speed | Session cache + indexing. |
| **10,000 events** (very heavy user) | Query latency, archive strategy | Aggressive archiving (>60 days); separate hot/cold storage. |
| **100,000 events** (multi-year accumulation) | Search performance | Incremental indexing; search limits ("show only past 2 years"). |
| **Millions of users** | Multi-tenancy, sharding | User-scoped cache; partition by user_id. |

---

## 14. Future Vision

### 14.1 Expansion to 10,000+ Events

As users accumulate Events over years (and AI generates more):
- Full-text search becomes critical.
- Archiving strategy keeps "today" responsive.
- Pattern analysis looks across all 10,000 past Events to predict future.
- Belief Engine uses historical Event data to infer user preferences.

### 14.2 Cross-System Event Intelligence

Events will bridge systems currently separate:
- **Travel Events**: Coordinate with Money (pre-trip budgeting), Living World (destination weather), People (who's going).
- **Health Events**: Coordinate with Brain (capture health notes), Living World (activity levels), Money (healthcare costs).
- **Project Events**: Coordinate with Goals, Deadlines, and Recommendations.

### 14.3 Automation & Delegation

Events will become actionable:
- **Auto-payment**: "This bill Event should auto-pay" → Finance system handles it.
- **Delegation**: "This Task Event should be delegated" → notify assigned person.
- **Scheduling**: "This Opportunity Event + this Maintenance Event should be scheduled together" → calendar system books.

### 14.4 Advanced AI

Events will drive AI behaviors:
- **Trend analysis**: "Over 12 months, bills have grown 3% per quarter. Project cash impact?"
- **Anomaly detection**: "This bill is 2x higher than usual. Alert?"
- **Smart suggestions**: "You're 0–3 for hitting this 'mow lawn' Event in the last month. Move to Sunday when you're less busy?"

### 14.5 Multi-User & Household

Events will support:
- **Shared Events**: Family dinner, household project, shared subscription.
- **Delegated Events**: Task assigned to a family member, with reminders to both.
- **Conflict detection**: Two people are assigned to the same time slot; flag it.

---

## 15. Known Risks & Trade-Offs

### 15.1 Confidence vs. Surfacing

**Risk**: Confident Events (1.0) may miss nuance; low-confidence Events (0.5) might be suppressed when user needs them.

**Mitigation**: 
- Low-confidence Events remain searchable.
- User can manually promote low-confidence Events to high-visibility.
- Belief Engine learns which low-confidence suggestions this user values.

### 15.2 AI Event Spam

**Risk**: AI generating too many Suggested Events, overwhelming the user.

**Mitigation**:
- Hard batching rule: Never send more than 1 AI-suggestion notification per day.
- Confidence floor: Never surface AI suggestion below 0.45 to user.
- Diminishing returns: Reduce frequency if user dismisses the same type.

### 15.3 Time Sensitivity Bias

**Risk**: Time-driven Events always outrank important-but-timeless Events (goals, health habits).

**Mitigation**:
- `time_sensitivity = "none"` allows importance to drive priority.
- Life-priority alignment provides tiebreaker.
- Context score includes non-time factors (health status, goal progress).

### 15.4 Recurring Event Explosions

**Risk**: A single recurring rule could spawn 1000+ child Events (decades of repetition).

**Mitigation**:
- Recurrence rules only generate children for next 90 days (rolling window).
- `recurrence_end_date` caps indefinite recursion.
- UI prevents ultra-long recurrences without explicit user confirmation.

### 15.5 Timezone Complexity

**Risk**: If Perch expands to multi-timezone users, time handling becomes complex.

**Mitigation**:
- Current implementation: device local time only (acceptable for single-user tool).
- Future: `timezone` field is reserved but not used; future expansion can fill it in.
- Recommendation: Use IANA timezone strings (standard); avoid hand-rolled timezone math.

### 15.6 Conflict Resolution in Multi-Source Scenarios

**Risk**: Same Event (e.g., a bill) appears in both manual entry and email-parsed form; system must not duplicate or conflict.

**Mitigation**:
- Deduplication logic in Event creation: "Does this Event already exist?" (check date, amount, description).
- If duplicate detected, merge them: record both sources, highest confidence wins, user is alerted to the discrepancy.
- Truth Engine surfaces conflict: "Your mortgage appears to be due March 15 (calendar) or March 16 (email); confirm?"

---

## 16. Architecture Recommendations

### 16.1 Implementation Priority

1. **Phase 1**: Unify Event object, build Event lifecycle state machine, implement basic Priority scoring (confidence + time + importance).
2. **Phase 2**: Integrate with existing Priority Engine; consolidate the four independent scorers into one using Event System.
3. **Phase 3**: Build Event ↔ Notification bridging; implement notification strategies (silent, digest, alert).
4. **Phase 4**: AI Event generation from patterns, predictions, and suggestions.
5. **Phase 5**: Advanced features (automation, delegation, multi-user).

### 16.2 Data Storage Model

**SQLite (current Perch stack)**:
- Store Events as JSON objects in a `perch_events` table.
- Columns: `id`, `type`, `category`, `status`, `due_date`, `priority_score`, `data` (JSON), `created_at`, `updated_at`.
- Indexes on: `due_date`, `status`, `category`, `priority_score`.
- Separate `perch_events_archive` table for completed/expired Events >30 days.

**Alternative (future, if scaling needs grow)**:
- PostgreSQL with JSONB support for flexibility + full-text search.
- Document DB (Firestore) for simpler deployment, built-in multi-tenancy.

### 16.3 API & Query Layer

**Core Query Functions** (building on existing `PerchEvents` in Chapter 3):
- `Event.getById(id)` — fetch single Event by ID.
- `Event.all()` — all active Events (cached for session).
- `Event.getToday()` — today's Events.
- `Event.getThisWeek()` — this week's Events.
- `Event.getByStatus(status)` — filter by lifecycle state.
- `Event.getByCategory(category)` — filter by domain.
- `Event.getByPriority()` — sorted by priority_score descending.
- `Event.search(query)` — full-text search.

**Mutation Functions**:
- `Event.create(data)` — create new Event.
- `Event.update(id, fields)` — update mutable fields.
- `Event.complete(id, notes)` — mark complete.
- `Event.defer(id, new_date)` — reschedule.
- `Event.snooze(id, until_timestamp)` — temporarily suppress.
- `Event.cancel(id, reason)` — cancel Event.
- `Event.archive(id)` — move to archive.

### 16.4 Voice & Presentation

Every Event surfaces through Voice Engine. Voice rules (Chapter 11) apply:
- Tone depends on Event type and user's relationship to it.
- Example: Bill → financial tone; Goal contribution → motivational tone.
- Metadata in Event (`metadata.tone`, `metadata.emoji_hint`) feeds Voice.

---

## 17. Conclusion

The Event System is Perch's bridge between Memory and Intelligence. It declares **what matters**, **when it matters**, and **how much**. By unifying events under one object model, lifecycle, and scoring regime, Perch can scale from 100 events to millions while remaining coherent, honest, and responsive.

The system is designed to:

- **Support user-created and AI-generated Events equally**, both Truth-gated and confidence-scored.
- **Connect every domain** (Money, Goals, Health, Family, Projects) via a single Event taxonomy.
- **Feed all downstream engines** (Priority, Recommendation, Voice, Notifications, Widgets) with deterministic, explainable data.
- **Stay honest**: Confidence matters; absence is surfaced, not hidden; conflicts are exposed, not silently resolved.
- **Scale intelligently**: From 100 to millions of Events, caching and archiving keep the system responsive.

This is the Event System v1.

---

## Change Log

| Date | Version | Change |
|---|---|---|
| (Current) | 1.0 | Event System v1 designed. Object schema, lifecycle, taxonomy, priority scoring, AI event generation, notification philosophy, widget consumption, performance strategy, and integration with existing engines documented. |
