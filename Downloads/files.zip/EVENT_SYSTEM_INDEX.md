# Perch Event System v1 — Complete Documentation Index

This index guides you through the complete Event System architecture designed for Perch.

## Document Map

### 1. **EVENT_SYSTEM.md** (Primary Design Document)
**Purpose**: The canonical architectural specification for the Event System.

**Contents**:
- Chapters 1–17 covering:
  - Purpose & Vision (§1–3)
  - The Event Object — all 50+ fields documented (§4)
  - Event Taxonomy — 15 event types + expansion (§5)
  - Event Lifecycle — state machine and transitions (§6)
  - Priority Scoring Model — formula, components, examples (§7)
  - Truth Gating & Confidence — how Truth Engine interacts (§8)
  - AI-Generated Events — sources, acceptance, spam prevention (§9)
  - Relationships & Integration — connections to all Perch layers (§10)
  - Notification Philosophy — strategies, batching, suppression (§11)
  - Widget Consumption — how surfaces use Events (§12)
  - Performance, Caching & Scaling — 1 to 1M+ events (§13)
  - Future Vision — scaling roadmap (§14)
  - Risks & Trade-offs (§15)
  - Architecture Recommendations (§16)
  - Conclusion & Change Log (§17)

**Read this first** if you're new to the Event System.

**Key Design Principles**:
- Events are declarative (what is time-sensitive), not imperative (what must happen)
- Time is the primary dimension
- AI-generated events are first-class
- Truth gates all events before surfacing
- One unified priority scoring model

---

### 2. **EVENT_OBJECT_SCHEMA.md** (Data Model Specification)
**Purpose**: Complete technical specification of the Event object and data storage.

**Contents**:
- TypeScript interface (full type definition)
- JSON schema examples (full Event, recurring, child, AI-suggested)
- SQLite schema (table design, indexes)
- Validation rules & constraints
- Database queries (common patterns)
- Query examples (range queries, search, relationships)

**Use this** when implementing Event storage and queries.

**Key Sections**:
- Identity & metadata (id, type, category, status, source, timestamps)
- Temporal dimensions (dates, times, recurrence, timezone)
- Relationship to user (importance, priority, confidence, goals, health)
- Status & completion (lifecycle state tracking)
- Hierarchy & relationships (parent-child, related events)
- Notification & surface control (strategies, timing, suppression)

---

### 3. **EVENT_PROCESSING_PIPELINE.md** (Data Flow)
**Purpose**: Complete trace of how Events move from creation to user-facing surface.

**Contents**:
- High-level pipeline diagram
- 7 detailed stages:
  1. Ingestion & Source
  2. Event Creation & Validation
  3. Truth Gating & Confidence Scoring
  4. Lifecycle State Placement
  5. Priority Scoring
  6. Notification Queue
  7. Surface Rendering
- Asynchronous processes (notifications, recurrence, archival)
- Error handling & edge cases
- Performance considerations

**Use this** to understand the complete data flow and how events surface to the user.

**Key Concepts**:
- Pipeline is atomic: creation → validation → truth gate → lifecycle → priority → notification → render
- Recurrence generates children on demand (90-day rolling window)
- Scoring is recomputed per session
- Notifications are batched to reduce spam

---

### 4. **EVENT_SYSTEM_INTEGRATION.md** (Architecture Connections)
**Purpose**: How Event System integrates with all existing Perch layers.

**Contents**:
- Memory Layer Integration (§1)
  - Calendar & Obligations → Events
  - Brain/Captures → Events
  - Money/Bills → Financial Events
  - Goals → Milestone Events
  - Projects → Deadline Events
  - Feedback loop: completions → beliefs

- Priority Engine Integration (§2)
  - Replaces 4 fragmented scorers with one unified model
  - Priority.score() inputs from Event fields
  - Priority output to all surfaces
  - Deterministic rendering across Today, Money, Week, etc.

- Truth Engine Integration (§3)
  - Confidence floors per Event type
  - Phrasing guidance per confidence level
  - Conflict detection & resolution
  - Source lineage tracking

- Recommendation Engine Integration (§4)
  - Clear boundary: Events (facts) vs. Recommendations (actions)
  - Events feed Recommendation Engine
  - AI can generate Events from recommendations

- AI Event Generation Strategy (§5)
  - 6 sources: calendar patterns, financial data, email, behavior, weather, goals
  - Confidence evolution (user acceptance/dismissal)
  - Spam prevention (batching, frequency caps, learning)

- Notification System Integration (§6)
  - Strategies per Event type
  - Smart batching (5 bills → 1 digest)
  - Suppression & preferences

- Widget Consumption (§7)
  - Today, Week, Money, Bills, Travel, Work, Health, Projects widgets
  - All consume Events consistently

- Voice Engine Integration (§8)
  - Events are phrased by Voice per tone rules
  - Confidence affects phrasing (certain vs. uncertain)

- Summary Data Flow (§9)
  - End-to-end diagram from sources through surfaces

**Use this** to understand how Event System connects to the rest of Perch.

---

### 5. **EVENT_SYSTEM_FINAL_RECOMMENDATIONS.md** (Strategy & Roadmap)
**Purpose**: Evaluation, risks, implementation roadmap, and final recommendations.

**Contents**:
- Architecture Evaluation (strengths, trade-offs)
- 7 Known Risks (with probability and mitigation)
  1. Confidence floor calibration
  2. AI event spam
  3. Recurring event explosion
  4. Priority score volatility
  5. Truth-gating suppresses useful events
  6. Timezone complexity
  7. Multi-source conflict resolution

- Future Expansion Roadmap (6 phases, 6 months)
  - Phase 1: Unify Priority Engine
  - Phase 2: Truth Gating at Intake
  - Phase 3: Notification System
  - Phase 4: AI Event Generation
  - Phase 5: Advanced Features (automation, delegation)
  - Phase 6+: Living World Integration

- Implementation Roadmap (6-week build plan)

- Success Criteria (per phase)

- 5 Architectural Decisions (constitutional rules)

- 10 Questions for Design Review

- Competitive Advantages

- Final Recommendation: Implement Phase 1 immediately (3–4 weeks)

**Use this** for roadmap planning, risk assessment, and executive summary.

---

## Navigation by Role

### For Product Managers / Decision Makers

1. Read: **EVENT_SYSTEM.md** §1–3 (Purpose, Vision, Philosophy)
2. Skim: **EVENT_SYSTEM_FINAL_RECOMMENDATIONS.md** (Risks, Competitive Advantages)
3. Review: Implementation Roadmap (6 phases, 6 months)

**Time**: 20–30 minutes

---

### For Software Architects

1. Read: **EVENT_SYSTEM.md** (All sections; this is the primary spec)
2. Deep-dive: **EVENT_SYSTEM_INTEGRATION.md** (How it connects to Priority, Truth, Voice)
3. Review: **EVENT_PROCESSING_PIPELINE.md** (Data flow; identify optimization points)
4. Reference: **EVENT_OBJECT_SCHEMA.md** (Storage design)

**Time**: 2–3 hours

---

### For Backend Engineers (Implementing Phase 1)

1. Reference: **EVENT_OBJECT_SCHEMA.md** (Create SQLite schema, CRUD functions)
2. Follow: **EVENT_PROCESSING_PIPELINE.md** §1–4 (Implement ingestion through lifecycle placement)
3. Implement: **EVENT_SYSTEM.md** §7 (Priority scoring formula)
4. Test against examples in **EVENT_OBJECT_SCHEMA.md** and **EVENT_PROCESSING_PIPELINE.md**

**Time**: 3–4 weeks of focused engineering

---

### For UI/Frontend Engineers

1. Skim: **EVENT_SYSTEM.md** §11–12 (Notifications, Widgets)
2. Reference: **EVENT_PROCESSING_PIPELINE.md** §7 (Surface Rendering)
3. Deep-dive: **EVENT_SYSTEM_INTEGRATION.md** §7–8 (Widget Consumption, Voice Engine)

**Time**: 1–2 hours (then as-needed reference during implementation)

---

### For Voice/Content Designers

1. Focus: **EVENT_SYSTEM.md** §8 (Truth Gating)
2. Reference: **EVENT_SYSTEM_INTEGRATION.md** §8 (Voice Engine Integration)
3. Examples: **EVENT_OBJECT_SCHEMA.md** (See phrasing guidance)

**Time**: 30–60 minutes

---

## Key Concepts Summary

### Event Object

A unified representation of time-bound information. Contains:
- Identity (id, type, category, status)
- Temporal (due_date, start_date, end_date, recurrence)
- User relationship (importance, confidence, goal connection, health impact)
- Lifecycle (completion state, timestamps)
- Relationships (parent, children, related events, people, goals)
- Control (notification strategy, suppression)

---

### Event Lifecycle

```
created → scheduled → active/upcoming → urgent → completed
                        ↓
                      archived
```

With optional: snoozed, deferred, cancelled, expired.

---

### Event Taxonomy

**15 canonical types:**
- Core: reminder, deadline, appointment, maintenance, financial, habit, goal, milestone
- AI/System: notification, alert, opportunity, recurring_event, suggested_event, system_event, external_event

---

### Priority Scoring Formula

```
priority_score = min(100, max(0,
  importance×50 + 
  time_urgency(0–30) + 
  confidence×20 + 
  context(0–20) + 
  (goal_connected ? 15 : 0) +
  life_priority_alignment(0–15)
))
```

Deterministic tie-breaking: state → due_date → creation_time → ID.

---

### Truth Gating

Every Event has a confidence (0–1). Event type determines minimum:
- Financial: 0.85+ to surface; 0.95+ to surface prominently
- Health: 0.90+
- AI-suggestion: 0.55+
- Phrasing adjusts per confidence: "is" (high) vs. "may be" (low)

---

### Integration Points

Events are:
- **Input from**: Calendar, Money, Brain, Goals, Projects, Living World, Email, Patterns
- **Processed by**: Truth Engine (confidence gating), Priority Engine (scoring)
- **Output to**: Today, Money, Week, Widgets, Recommendation Engine, Voice Engine, Notification System

---

## Questions? Design Review Points

**Technical**:
- Confidence floor calibration per Event type (needs user testing)
- Recurrence rule complexity (start simple, add complexity later)
- Timezone handling (defer to phase 2+)
- Backward compatibility with existing data

**Product**:
- Where do AI-suggested Events appear? (Suggestions page? Digest?)
- User suppression: entire categories or individual Events?
- Default notification strategies per type

**Strategic**:
- Multi-user / household support (future)?
- When do Events trigger automation (auto-pay, delegation)?
- Learning loop (how does Perch learn what matters to user)?

---

## Implementation Checklist

### Phase 1: Unified Priority Engine (3–4 weeks)

- [ ] Define Event object schema
- [ ] Create SQLite schema
- [ ] Build Event ↔ Bill converter
- [ ] Build Event ↔ Capture converter
- [ ] Build Event ↔ Appointment converter
- [ ] Implement Priority.score(event, context)
- [ ] Route all surfaces through Priority.score()
- [ ] Remove orphan scorers
- [ ] Test: all surfaces show Events in same order
- [ ] Performance test: priority scoring < 200ms for 1000 events

---

## Change Log

| Version | Date | Change |
|---------|------|--------|
| 1.0 | Current | Event System v1 designed. Complete documentation (5 files) covering object model, pipeline, integration, and implementation strategy. Ready for Design Review. |

---

## Document Dependencies

```
EVENT_SYSTEM.md (primary spec)
    ↓
    ├→ EVENT_OBJECT_SCHEMA.md (implements §4)
    ├→ EVENT_PROCESSING_PIPELINE.md (implements §6–7)
    ├→ EVENT_SYSTEM_INTEGRATION.md (implements §10–11)
    └→ EVENT_SYSTEM_FINAL_RECOMMENDATIONS.md (implements §14–16)
```

All documents reference each other; read as interconnected chapters of the Design Bible.

---

## Next Steps

1. **Design Review** (1–2 hours)
   - Product, Architecture, Engineering teams review this documentation
   - Resolve questions (see "Questions?" section above)
   - Approve for implementation

2. **Phase 1 Planning** (1 week)
   - Break down into engineering tasks
   - Assign engineers
   - Estimate timeline (3–4 weeks)
   - Create Jira/GitHub issues

3. **Phase 1 Execution** (3–4 weeks)
   - Build Event schema and storage
   - Build converters
   - Implement Priority.score()
   - Integration test across all surfaces

4. **Phase 1 Validation** (1 week)
   - User testing (priority accuracy)
   - Performance testing
   - Bug fixes
   - Ship Phase 1

5. **Phase 2+ Planning** (ongoing)
   - Truth Gating, Notifications, AI Events, etc.

---

**This concludes the Perch Event System v1 design documentation.**

**Status**: Ready for Design Review → Engineering → Implementation

**Confidence**: 85% (philosophy settled; integration depth with future engines is open)

**Recommendation**: Implement Phase 1 immediately (Unified Priority Engine). Roadmap for Phases 2–6 is clear.

