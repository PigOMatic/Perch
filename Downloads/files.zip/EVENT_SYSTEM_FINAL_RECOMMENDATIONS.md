# Event System v1 — Final Architecture Recommendations

## Executive Summary

The Perch Event System v1 is a unified, Truth-gated, deterministically-scored framework for managing all time-bound information in Perch. It consolidates existing fragmented event handling into one coherent architecture that scales from 100 events to millions, supports both human-created and AI-generated events, and feeds all downstream engines (Priority, Recommendation, Voice, Notifications, Widgets) with consistent, explainable data.

**Status:** Concept (design complete; implementation pending)

**Confidence:** 85% (philosophy settled; integration depth with future engines is open)

**Recommended Implementation Priority:** Phase 1 (immediate), as it unifies existing Priority Engine fragmentation

---

## 1. Architecture Evaluation

### Strengths

1. **Unified Taxonomy**: Single Event object replaces fragmented event modeling across Calendar, Money, Brain, Goals.

2. **Truth-Gated at Intake**: Every Event is confidence-scored and gated before surfacing; no unsupported claims leak to user.

3. **Deterministic Priority Scoring**: One Priority.score() function replaces four independent scorers; all surfaces agree on what matters.

4. **Scalable Design**: 
   - Session caching handles 1,000s of events efficiently.
   - Archiving strategy keeps active query set small.
   - Recurrence rules (one template → N children) avoid event explosion.

5. **AI-Native**: AI-generated and user-created Events are first-class; confidence-scoring allows gradual promotion (suggestion → confirmed → fact).

6. **Extensible**: New Event types, notification strategies, and surfaces can be added without breaking core architecture.

7. **Relationship-Rich**: Events connect to Memory, People, Goals, Projects, Living World; rich querying possible.

### Trade-Offs

1. **Complexity Growth**: Consolidating 4 scorers + adding confidence gates + adding relationships = significant refactoring.

2. **Migration Burden**: Existing code (Chapter 3's `PerchEvents`, Chapter 8's `whyNowScore`, Chapter 2's `bills`) must be updated to use Event objects.

3. **Recurrence Complexity**: Generating child Events for recurring patterns requires careful handling (exception dates, parent updates, cascading deletes).

4. **Confidence Calibration**: Determining the right confidence floor for each Event type requires user testing and iteration.

5. **Performance**: Priority scoring on every session load could be slow if naive. Requires careful caching.

---

## 2. Known Risks

### Risk 1: Confidence Floor Calibration

**Problem**: If confidence floors are too high, legitimate low-confidence suggestions (AI-generated Events) are suppressed. If too low, users are flooded with noisy recommendations.

**Probability**: High (confidence tuning is empirically hard)

**Mitigation**:
- Start with conservative floors (bill: 0.85, health: 0.90, AI-suggestion: 0.55).
- Monitor user dismissal rates per Event type; adjust quarterly.
- Provide user preference settings to customize confidence floor per category.

---

### Risk 2: AI Event Spam

**Problem**: AI generating too many suggested Events, or suggesting the same thing repeatedly, making Perch feel noisy.

**Probability**: High (AI systems are prone to over-generating)

**Mitigation**:
- Hard batching rule: max 1 notification per day for suggestions.
- Confidence decay: Repeated dismissals reduce AI confidence in that Event type by 20% (compound).
- Rate limiting: AI suggests "mow lawn" max 1x per week, even if weather is perfect every day.
- Learning: Track which AI suggestions user acts on; weight similar future suggestions higher.

---

### Risk 3: Recurring Event Explosion

**Problem**: A recurring Event could generate 1000+ child Events if rule is not capped or if user has many recurring Events.

**Probability**: Medium (only if users create very long-term recurring rules)

**Mitigation**:
- Generate children only for next 90 days (rolling window).
- UI prevents recurrence past a user-specified end date.
- Automatic pruning: Delete completed children older than 30 days.

---

### Risk 4: Priority Score Volatility

**Problem**: If priority_score swings wildly between sessions, user experiences "jitter"—yesterday's #1 Event isn't there today.

**Probability**: Medium (if context_score is too reactive)

**Mitigation**:
- Smooth scoring: Use step functions, not sharp cliffs. "Days until" boosts gradually, not suddenly at threshold.
- Session stability: Recompute scores once per load, not continuously.
- Tiebreaker stability: Deterministic tiebreaking ensures consistent ordering.

---

### Risk 5: Truth-Gating Inadvertently Suppresses Useful Low-Confidence Events

**Problem**: A genuinely useful AI suggestion (e.g., "you should call your friend more") gets gated off because confidence is 0.55 and health floor is 0.60.

**Probability**: Medium (requires careful floor tuning)

**Mitigation**:
- Low-confidence Events remain searchable, never fully deleted.
- "Suggestions" surface shows low-confidence events separately.
- User can "accept this suggestion" to bump confidence to 0.85.
- Logging: Track which gated-off Events user would have valued (if they find it via search).

---

### Risk 6: Timezone Complexity

**Problem**: If Perch expands to multi-timezone users (travel, remote teams), time handling becomes complex.

**Probability**: Low (Perch is single-user; not yet multi-timezone)

**Mitigation** (future-proofing):
- Event schema includes `timezone` field (currently null, can be filled in later).
- All time logic uses IANA timezone strings (standard; portable).
- No custom timezone math in code; use libraries (e.g., `date-fns-tz`).

---

### Risk 7: Conflict Resolution in Multi-Source Scenarios

**Problem**: Same Event (e.g., bill) appears from manual entry, email parser, and bank import—three different dates. Which is truth?

**Probability**: Medium (only with external integrations)

**Mitigation**:
- Deduplication at Event creation: Check if Event already exists by name, amount, ~date.
- Merge conflicts: Record all sources, use highest confidence, surface disagreement.
- Truth Engine decision: "Your bill appears to be due March 15 (calendar) or March 16 (email). Confirm?"
- User resolution: User confirms; confidence jumps; system learns which source is trustworthy.

---

## 3. Future Expansion Roadmap

### Phase 1 (Immediate): Unify Priority Engine

**Goal**: Replace four independent Priority scorers with one unified Event.score() function.

**Work**:
1. Define Event object schema ✓ (complete)
2. Build Event ↔ Bill converter
3. Build Event ↔ Capture converter
4. Build Event ↔ Appointment converter
5. Implement Priority.score(event, context)
6. Route all surfaces (Today, Money, Week) through Priority.score()
7. Remove orphan duplicate scorer (`perch_core_merge.js`)

**Benefit**: All surfaces agree on priority; easier to debug and maintain.

**Timeline**: 2–4 weeks of engineering

---

### Phase 2 (Month 2–3): Truth-Gating at Event Intake

**Goal**: No Event surfaces without passing Truth Engine confidence floor.

**Work**:
1. Define confidence floors per Event type
2. Build Truth.gate(event) function
3. Implement phrasing rules (confidence → tone in Voice Engine)
4. Build Suggestions surface for low-confidence Events
5. Add user acceptance/rejection workflow

**Benefit**: No unsupported claims reach user; higher trust.

**Timeline**: 2–3 weeks of engineering

---

### Phase 3 (Month 3–4): Notification System

**Goal**: Smart batching, context-aware timing, user suppression.

**Work**:
1. Build notification strategies per Event type
2. Implement batching logic (5 bills → 1 digest)
3. Add notification scheduling (advance hours, digest timing)
4. Build user suppression preferences UI
5. Test notification frequency and user satisfaction

**Benefit**: Users aren't overwhelmed; notifications feel helpful, not annoying.

**Timeline**: 2–3 weeks of engineering

---

### Phase 4 (Month 4–5): AI Event Generation

**Goal**: System can suggest Events from patterns, predictions, and recommendations without flooding user.

**Work**:
1. Implement pattern detection (calendar, habits, financial)
2. Build Suggestions surface with accept/reject/modify
3. Add confidence decay (dismissals lower AI confidence)
4. Implement frequency caps (max 1 "mow lawn" per week)
5. Build learning loop (track which suggestions user acts on)

**Benefit**: AI-enhanced Perch without spam.

**Timeline**: 3–4 weeks of engineering

---

### Phase 5 (Month 5–6): Advanced Features

**Goal**: Automation, delegation, multi-user (if Perch expands).

**Work**:
1. Auto-payment Events → Finance system integration
2. Delegated Events (things owed *to* others)
3. Shared Events (household calendar)
4. Event dependencies (task A blocks task B)

**Benefit**: Perch becomes a coordinating system, not just a dashboard.

**Timeline**: 4–6 weeks of engineering

---

### Phase 6+ (Beyond Month 6): Living World Integration

**Goal**: Events influenced by Living World state (weather, location, mood).

**Work**:
1. Living World provides context to Priority scoring
2. Weather Events feed Opportunity suggestions
3. Location-aware reminders
4. Circadian-aware notification timing

**Benefit**: Proactive, context-aware intelligence.

**Timeline**: 6+ weeks (depends on Living World architecture)

---

## 4. Implementation Roadmap

### Build Order

1. **Event Schema & Storage** (Week 1)
   - Define Event object (§4 of EVENT_SYSTEM.md)
   - Create SQLite schema (EVENT_OBJECT_SCHEMA.md)
   - Build CRUD functions (get, create, update, archive)

2. **Event Converters** (Week 2)
   - Bill → Financial Event
   - Capture → Reminder Event
   - Appointment / Shift → Appointment Event
   - Future Horizon → Milestone Event

3. **Priority Scoring** (Week 3)
   - Implement Priority.score(event, context)
   - Route existing surfaces (Today, Money, Week) through it
   - Verify deterministic ordering

4. **Truth Gating** (Week 4)
   - Confidence floor per Event type
   - Gate low-confidence Events
   - Phrasing rules to Voice Engine

5. **Notification Queue** (Week 5)
   - Notification scheduling
   - Batching logic
   - User suppression preferences

6. **Testing & Iteration** (Weeks 6+)
   - User testing on priority accuracy
   - Confidence tuning
   - Performance profiling
   - Bug fixes

---

## 5. Success Criteria

### Phase 1 Success (Unified Priority)
- [ ] One Priority.score() function used by all surfaces
- [ ] All surfaces show Events in same order
- [ ] No orphan scorers or dead code
- [ ] Performance: priority scoring < 200ms for 1000 events

### Phase 2 Success (Truth Gating)
- [ ] 0 Events with confidence < floor appear on user-facing surfaces
- [ ] User satisfaction with Event accuracy > 90%
- [ ] Phrasing reflects confidence (uncertain events use "may," "likely," etc.)

### Phase 3 Success (Notifications)
- [ ] User doesn't feel notification spam (< 5 notifications/day on average)
- [ ] Batching works (3 bills → 1 digest)
- [ ] User dismissal rate < 20%

### Phase 4 Success (AI Events)
- [ ] AI suggests 3–5 useful Events/week (user acceptance rate > 50%)
- [ ] No "mow lawn" suggestion appears more than weekly
- [ ] System learns from dismissals (diminishing duplicate suggestions)

### Phase 5+ Success
- [ ] Events automate common tasks (auto-pay, delegations)
- [ ] Users feel Perch is coordinating their life, not just tracking

---

## 6. Architectural Decisions (Constitutional)

### Decision 1: Events Are Declarative, Not Imperative

**Rule**: An Event describes *what is time-sensitive*, not *what must happen*.

**Implication**: Event is never a command. "Duke Energy bill due tomorrow" ≠ "You must pay Duke Energy."

**Consequence**: Recommendation Engine decides what user should do; Event System only tracks what's time-bound.

---

### Decision 2: One Priority.score(), Not Type-Specific Scorers

**Rule**: All Event types use the same scoring formula (importance + time + confidence + context + goal + life-priority).

**Implication**: A financial Event and a health Event compete on the same scale. No hidden favoritism.

**Consequence**: All surfaces agree on priority. Simpler to debug, test, and maintain.

---

### Decision 3: Truth Outranks Convenience

**Rule**: If an Event doesn't meet the confidence floor, it does not surface to user, even if it would be "helpful."

**Implication**: Low-confidence suggestions stay searchable but don't interrupt the user.

**Consequence**: Perch remains trustworthy; users believe what Perch claims.

---

### Decision 4: AI-Generated Events Are First-Class

**Rule**: AI-suggested Event and user-created Event use the same object model, lifecycle, and scoring.

**Implication**: No separate "suggestions" engine; suggestions *are* Events with lower initial confidence.

**Consequence**: User acceptance/dismissal feedback naturally trains the AI. Over time, good suggestions become facts.

---

### Decision 5: Relationships Are Explicit

**Rule**: Every Event can link to Memory, People, Goals, Projects, other Events.

**Implication**: No implicit relationships; all connections are queryable and explainable.

**Consequence**: Cross-domain intelligence (Recommendation Engine) has rich graph to work with.

---

## 7. Questions for Design Review

### Technical

1. **Confidence Calibration**: What are the right confidence floors per Event type? (This will need user testing.)

2. **Recurrence Complexity**: How deep should the recurrence rule engine be? (Start simple—daily, weekly, monthly, yearly; add complex rules later.)

3. **Timezone Support**: Can we defer timezone handling (use null / device local for now) and implement later?

4. **Backward Compatibility**: Do we need to migrate existing Events in the repository, or build new Event table alongside old structures?

### Product

5. **Suggestions Surface**: Where/how do AI-suggested Events appear? (New "Suggestions" page? Panel on Today? Digest email?)

6. **User Suppression**: Should user be able to hide entire Event categories, or just specific Events?

7. **Notification Defaults**: What's the right default notification strategy per Event type? (Conservative? Aggressive?)

### Strategic

8. **Multi-User Future**: Does this architecture scale to household/team Events, or is it single-user forever?

9. **Automation**: At what point do Events trigger automatic actions (auto-pay, delegations, scheduling)?

10. **Learning Loop**: How does Perch learn which Events matter most to this user? (Via dismissals? Completed Events? Time spent?)

---

## 8. Risks of Delay

If Event System v1 is not implemented soon:

1. **Priority Engine remains fragmented**: Four scorers, inconsistent tie-breaking, all four systems live in parallel indefinitely.

2. **AI Features delayed**: Can't confidently add AI suggestions (pattern detection, predictions) without unified Event framework.

3. **Notification system ad-hoc**: No systematic approach to when/how often Perch interrupts user.

4. **Scalability wall**: At 1000+ events, query performance and priority scoring slow down without caching strategy.

5. **Tech debt compounds**: Each new feature adds another special case; system becomes harder to maintain.

---

## 9. Competitive Advantages

Once Event System v1 is live, Perch will have:

1. **Deterministic Priority**: Same answer every time; explainable to user ("why did this rise?").

2. **Truth-Gated Intelligence**: No fabricated claims; AI suggestions are labeled as such.

3. **Unified Cross-Domain Understanding**: A bill, a health appointment, and a goal milestone compete fairly on one scale.

4. **Scalable to Millions**: Architecture designed from the start to handle 10,000+ events per user without degradation.

5. **AI-Native from Ground Up**: AI suggestions are first-class Events, not bolted-on features.

---

## 10. Final Recommendation

### Implement Phase 1 (Unified Priority Engine) Immediately

**Why**: 
- Resolves known architectural debt (Chapter 8 §17: "not one engine").
- Unblocks future AI features.
- Improves user experience immediately (consistent priority).
- Foundation for all downstream phases.

**Timeline**: 3–4 weeks of focused engineering.

**Confidence**: Very high (design is complete; engineering is straightforward refactoring).

**Next Step**: Engineering team begins Event schema + converters (Week 1) after this design is approved.

---

## 11. Conclusion

The Perch Event System v1 is a comprehensive, scalable, Truth-gated architecture for managing time-bound information. It unifies existing fragmented event handling, supports AI-generated events, and feeds all downstream engines with deterministic, explainable data.

The design is stable; the implementation path is clear. Building Phase 1 will immediately improve Perch's coherence and unblock future intelligence features.

This is the event system Perch needs to scale from alpha to millions of users without losing its core promise: clarity, presented beautifully.

---

## Deliverables Checklist

- [x] EVENT_SYSTEM.md — Core design (Chapters 1–17)
- [x] EVENT_OBJECT_SCHEMA.md — JSON schema, TypeScript interface, SQLite schema
- [x] EVENT_PROCESSING_PIPELINE.md — Data flow from ingestion through rendering
- [x] EVENT_SYSTEM_INTEGRATION.md — Integration with Memory, Priority, Truth, Voice, Notifications
- [x] EVENT_SYSTEM_FINAL_RECOMMENDATIONS.md — This document (roadmap, risks, recommendations)

Additional supporting documents (as needed):
- State diagram (visual representation of Event lifecycle)
- Example queries (common patterns)
- Performance tuning guide

---

**Document Version**: 1.0

**Date**: Current

**Status**: Ready for Design Review → Engineering → Implementation

