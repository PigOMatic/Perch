# Event System Integration Architecture

How the Event System connects to Perch's existing layers and future systems.

## 1. Memory Layer Integration

### 1.1 Event ← Memory (Ingestion)

Memory stores facts. Events declare when facts matter. The relationship is: **every time-bound fact becomes an Event.**

#### From Calendar & Obligations (Chapter 3)

**Current State:**
- `PerchDate` and `PerchEvents` exist and aggregate events from multiple sources.
- Events are modeled as calendar entries, obligations, and bills.

**Integration:**
- Event System becomes the unified container for all `PerchEvents.all()` results.
- Instead of returning ad-hoc objects, `PerchEvents.all()` returns Event objects.
- Example:
  ```
  PerchEvents.getThisWeek()
  → Returns array of Event objects (bills, appointments, goals, captures)
  → All Event objects have consistent schema, lifecycle, priority_score
  → All can be sorted, filtered, scored uniformly
  ```

**Migration Path:**
1. Define Event schema (done in EVENT_OBJECT_SCHEMA.md).
2. Build Event ↔ Bill converter (bill → financial Event).
3. Build Event ↔ Appointment converter (shift, opportunity → appointment Event).
4. Build Event ↔ Obligation converter (waiting items, future_horizon → Events).
5. Retire ad-hoc event objects; use Event uniformly.

#### From Brain/Captures (Chapter 6)

**Current State:**
- Brain captures are stored as `captures[]` with `perch_action` tags.
- Example: a capture tagged `reminder` has a due date but is not time-scored.

**Integration:**
- Capture with `expected` date → Reminder Event.
- Capture with `perch_action: "waiting_on"` + `expected` date → Waiting Event.
- Capture with `recurring: true` → Recurring Event template.
- Example:
  ```
  Capture:
    {
      "content": "Call Mom",
      "perch_action": "waiting_on",
      "expected": "2026-07-15",
      "recurring": "weekly"
    }
  
  Converted to Event:
    {
      "type": "reminder",
      "title": "Call Mom",
      "due_date": "2026-07-15",
      "recurrence": { pattern: "weekly" },
      "related_memory_ids": ["capture-123"],
      "source": "pattern_detected"
    }
  ```

**When a Brain Capture Becomes an Event:**
- User explicitly tags it with a due date.
- AI detects a pattern and suggests a recurring reminder.
- Capture is recurring; system auto-generates Events.

#### From Money (Chapter 2)

**Current State:**
- Bills are stored in `bills[]` with `due_day`, `amount`, `category`.
- Account balances and transactions inform decisions.

**Integration:**
- Bill → Financial Event (monthly recurring).
- Income (paycheck) → Financial Event (biweekly or monthly recurring).
- Subscription charges → Financial Event (monthly or yearly).
- Example:
  ```
  Bill:
    { "name": "Duke Energy", "due_day": 15, "amount": 125 }
  
  Event (recurring template):
    {
      "id": "evt-recurring-duke-energy",
      "type": "financial",
      "title": "Duke Energy",
      "due_date": "2026-08-15",  // This month's instance
      "recurrence": { pattern: "monthly", day_of_month: 15 },
      "financial_impact": -12500,  // cents
      "related_memory_ids": ["bill-duke-energy"],
      "source": "derived_from_bill"
    }
  ```

**Threshold Events** (new type, future):
- System can generate Events when account balance crosses a threshold.
- Example: "Account balance dropped below $500" → Alert Event.
- These Events feed the Recommendation Engine: "Add income or defer expenses?"

#### From Goals (Chapter 4)

**Current State:**
- Goals stored in `future_horizon[]` with target dates and amounts.
- Goal progress is tracked separately.

**Integration:**
- Goal → Milestone Event (target date).
- Goal contribution checkpoint → Recurring Milestone Event (e.g., "$200/month").
- Goal dependency → Deadline Event (must reach X by Y to unblock Z).
- Example:
  ```
  Goal:
    { 
      "name": "Save $5000 for Yellowstone trip",
      "target_date": "2026-10-01",
      "target_amount": 500000  // cents
    }
  
  Events generated:
    1. "Trip target: reach $5000 by Oct 1" (Milestone)
       - type: "milestone"
       - goal_connection: ["goal-yellowstone"]
       - importance: 0.9
    
    2. "Contribute $200 to trip savings" (Recurring Goal Event, monthly)
       - type: "goal"
       - recurrence: { pattern: "monthly" }
       - goal_connection: ["goal-yellowstone"]
  ```

#### From Projects (Chapter 5)

**Current State:**
- Projects are concept-level; not yet implemented.

**Integration** (planned):
- Project → Collection of linked Events (milestones, deadlines, dependencies).
- Project milestone → Milestone Event.
- Project dependency → Deadline Event (blocks downstream task).
- Example:
  ```
  Project: "Ship Perch v0.5"
    Milestones:
      - "API spec frozen" (May 15)
      - "Alpha ready" (June 15)
      - "Beta release" (July 15)
  
  Events:
    - "API spec deadline" (Deadline Event, May 15)
    - "Alpha ready" (Milestone Event, June 15)
    - "v0.5 launch" (Milestone Event, July 15)
  ```

### 1.2 Event → Memory (Feedback)

Events are acted on; actions feed back to Memory.

#### Event Completion → Belief Formation

When an Event is marked complete:

```
Event completed: "Called Mom"
  completed_at: 2026-07-15T14:30:00Z
  
Action:
  1. Belief Engine observes: "User called Mom at 2:30 PM"
  2. Pattern: "User calls Mom on Sundays around 2 PM"
  3. Over time, if consistent: "User maintains weekly contact with Mom" (Belief)
  4. Confidence grows with repetition
```

#### Event Skipped/Missed → Deviation Detection

```
Event expired: "Gym session" (missed)
  due_date: 2026-07-08
  current_date: 2026-07-10
  completion_state: "expired"
  
Action:
  1. Belief Engine observes: "User skipped gym (planned Tuesday, didn't happen)"
  2. Check pattern: "User misses gym ~2/8 times on Tuesdays"
  3. Question: "Is Tuesday a bad day? Should we move gym to Thursday?"
  4. Store deviation for later pattern analysis
```

#### Priority Score Evolution → User Attention Learning

```
Similar Events (same type, category) with varying priority_scores:
  - Emergency fund contribution: Usually score 85
  - Gym session: Usually score 40
  - Surprise opportunity: Usually score 45
  
Belief Engine learns:
  "User prioritizes financial goals > health/opportunities"
  → Future recommendations weight financial items higher
```

---

## 2. Priority Engine Integration

The Priority Engine is the **primary consumer** of Events.

### 2.1 Current Priority Engine (Chapter 8) → Event System Bridge

**Current state:**
- Priority Engine has 4 independent scorers.
- No unified scoring interface.
- Events are implicitly managed in different places.

**Integration strategy:**

**Step 1: Unify Around Event System**
```
Old flow:
  Bill (data) → whyNowScore() → rank
  Capture (data) → _score → rank
  Event (data) → daysUntil sort → rank
  
New flow:
  All data → Event objects
  All Events → Priority.score(event) → 0–100
  All surfaces use one priority_score
```

**Step 2: Consolidate Scorers into Event.score()**
```
Priority.score(event, context) returns:
  {
    score: 0–100,
    breakdown: {
      base_score: 50,
      time_score: 25,
      confidence_score: 18,
      context_score: 5,
      goal_score: 15,
      life_priority_score: 12
    },
    explanation: "High priority because: urgent deadline + high importance + goal-aligned"
  }
```

**Step 3: Deterministic Tie-Breaking**
```
If two Events have score 85:
  1. Compare state: urgent > active > upcoming > scheduled
  2. Compare due_date: earlier wins
  3. Compare creation_time: older wins (stability)
  4. Compare ID: alphabetically (determinism)
```

### 2.2 Priority Scoring Inputs from Events

Every mutable field on an Event can influence Priority scoring:

| Event Field | Priority Impact | Example |
|---|---|---|
| `importance` | Base score (0–50) | importance=1.0 → +50 base |
| `due_date` / `time_remaining` | Time urgency (0–30) | due tomorrow → +25 time |
| `confidence` | Confidence boost (0–20) | confidence=1.0 → +20 |
| `status` (state) | State boost (0–5) | urgent state → +5 |
| `goal_connection` | Goal alignment (0–15) | top-3 goal → +15 |
| `life_priority_rank` | Tiebreaker (0–15) | rank 1 → +15 |
| `health_impact` | Context (0–10) | health_impact=0.8 → +8 if user health-focused |
| `financial_impact` | Context (0–8) | negative amount → boost if money tight |
| `tags` | Weight adjustments | tag "urgent" → +5 |

### 2.3 Priority Output to Surfaces

Once Priority Engine scores all active Events:

**Today Page:**
```
Priority.getTopEvents(date, limit=5)
  → Returns Events sorted by priority_score DESC
  → Today picks the #1 as "one thing"
  → Voice Engine phrases it
  → Render to page
```

**Money Page:**
```
Priority.getByCategory("financial")
  → Returns all financial Events sorted by priority_score
  → Display in order: most urgent at top
  → Visual: color code by days_until
```

**Week Page:**
```
Priority.getThisWeek()
  → Returns Events between today+0 and today+7
  → Sorted by priority_score within each day
  → Timeline layout
```

**Recommendation Engine** (future):
```
Priority.getTopOpportunities(limit=3)
  → Returns highest-scored Events that are Opportunities
  → Recommendation Engine reads top 3
  → Synthesizes cross-domain suggestion
  → Example: "Tuesday is clear + weather is good + lawn needs mowing → Mow Tuesday"
```

### 2.4 Deterministic Rendering Across All Surfaces

**Before Event System:**
- Today used `whyNowScore` (Scorer 1)
- Money used `priorityScore` (Scorer 2)
- Calendar used `daysUntil` sort (Scorer 4)
- Three surfaces disagreed about what mattered most

**After Event System:**
```
All surfaces use Priority.score(event) consistently:
  
  Today shows: Event with max priority_score
  Money shows: Financial Events sorted by priority_score
  Calendar shows: All Events sorted by priority_score
  Week shows: This-week Events sorted by priority_score
  
  Result: All surfaces agree on priority
  "Duke Energy bill" is #1 on Today, #1 on Money, prominent on Calendar
```

---

## 3. Truth Engine Integration

Every Event must pass Truth gating.

### 3.1 Truth Gating per Event Type

**Financial Events** (high confidence floor)
```
Bill due date:
  confidence required: 0.85+
  if < 0.85: "Your bill may be due March 15 (uncertain)"
  if < 0.50: Gate off; don't surface

Account balance:
  confidence required: 0.95+
  if < 0.95: Flag for manual review

Prediction (account will overdraft):
  confidence required: 0.70+
  if < 0.70: Marked as speculative, not surfaced
```

**Health Events** (high confidence floor)
```
Medication reminder:
  confidence required: 0.90+ (user or pharmacy confirmed)
  if < 0.85: "You may need to refill your medication" (uncertain)

Exercise goal:
  confidence required: 0.50+ (user's aspirational; OK to surface with lower confidence)

AI suggestion about health:
  confidence required: 0.80+ (no guesses about health)
  if < 0.80: Gate off entirely
```

**AI-Suggested Events** (medium confidence floor)
```
Pattern-detected reminder:
  confidence required: 0.60+
  if < 0.60: Surface only in Suggestions surface, not Today

Opportunity suggestion:
  confidence required: 0.55+
  if < 0.55: Search-accessible only

Prediction:
  confidence required: 0.65+
  if < 0.65: Not surfaced; logged internally only
```

### 3.2 Phrasing by Confidence

Voice Engine receives confidence from Event and adjusts tone:

```
Voice rules per confidence:
  0.95–1.0:    "Your mortgage is due March 15."
  0.85–0.94:   "Your mortgage is likely due March 15."
  0.75–0.84:   "Your mortgage should be due March 15."
  0.60–0.74:   "Perch believes your mortgage may be due March 15."
  0.40–0.59:   "You might want to check if your lawn needs mowing."
  < 0.40:      Not surfaced to user (gate off)
```

### 3.3 Conflict Detection

When two sources propose different dates for the same Event:

```
Scenario: Calendar says "March 15" for appointment; email says "March 14"

Detection:
  1. Event creation sees duplicate (same title, person, ~same date)
  2. Merge: Create single Event with both dates listed
  3. Confidence: Drop from 0.95 to 0.75 (uncertainty)

Surfacing:
  "Your appointment with Dr. Smith appears to be March 15 (calendar) 
   or March 14 (email). Which is correct?"

User action:
  - User confirms: "March 15 is correct" → confidence jumps to 0.98
  - System learns: Email was wrong; trust calendar more
```

### 3.4 Source Lineage

Every Event carries a `source` field for Truth Engine traceability:

```
Event:
  id: evt-duke-energy-march
  source: "user_created"
  related_memory_ids: ["capture-duke-energy-account"]
  
Truth Engine can trace:
  "User manually entered this event" 
  → High confidence (0.95)
  → Related to capture about bill account

Event:
  id: evt-lawn-suggestion
  source: "ai_suggested"
  metadata: {
    confidence_reason: "Clear weather window + grass growth",
    source_signals: ["weather_forecast", "lawn_growth_pattern"]
  }
  
Truth Engine can trace:
  "AI generated this based on weather and growth patterns"
  → Medium confidence (0.68)
  → Requires user acceptance or dismissal
```

---

## 4. Recommendation Engine Integration (Future)

Events feed Recommendations; Recommendations are not Events.

### 4.1 Relationship (Constitutional)

**Clear boundary:**
- **Event**: "Duke Energy bill is due tomorrow" (fact + time).
- **Recommendation**: "You should pay the Duke Energy bill now to avoid late fee" (action suggestion).

**Current problem (Chapter 8, §18):**
- Priority Engine reuses `whyNowScore` for Recommendations.
- This blurs Event ↔ Recommendation boundary.

**Future correction:**
```
Priority Engine → Event scoring (what rises for attention)
Recommendation Engine → Action suggestion (what should I do?)

Example:
  High-priority Events:
    1. Bill due tomorrow (Financial)
    2. Free time this afternoon (Opportunity)
    3. Good weather today (Context)
  
  Recommendation Engine reads these:
    "You have 2 hours free. Weather is clear. Could pay the bill now
     and then enjoy a walk."
  
  → Recommendation is cross-domain synthesis, not just priority ranking
```

### 4.2 Future AI Event Generation

Once Recommendation Engine is built, AI can generate Events more intelligently:

```
Recommendation: "Tuesday is a perfect day to mow the lawn"
  (cross-domain: weather + calendar + maintenance pattern)

AI thinking:
  "This is a good enough recommendation that I should create an Event for it
   to track whether the user does it, and learn from patterns."

Generated Event:
  type: "opportunity"
  title: "Good day to mow lawn"
  due_date: "2026-07-14"  (Tuesday)
  confidence: 0.72
  source: "ai_suggested"
  metadata:
    recommendation_derivation: true
    confidence_reason: "Clear weather + free schedule + grass overdue"
  tags: ["ai-opportunity"]

User action:
  - If user accepts: Event becomes Recurring (mowing reminder)
  - If user dismisses repeatedly: System learns not to suggest mowing

Result: AI learns which recommendations become real behavior
```

---

## 5. AI Event Generation Strategy

### 5.1 Event Generation Triggers

AI generates Events from:

**1. Calendar Analysis**
```
Observation: "User has therapy every Tuesday at 2 PM (8 consecutive Tuesdays)"
Proposed Event:
  type: "recurring_event" / "appointment"
  title: "Therapy session"
  recurrence: { pattern: "weekly", days: [2] }  // Tuesday
  time_of_day: "14:00"
  confidence: 0.85
  source: "pattern_detected"
  
User prompt: "Perch found a pattern. Should I track weekly therapy appointments?"
  [Yes] → Event created, confidence → 0.92
  [No] → Event dismissed; pattern suppressed
```

**2. Financial Data**
```
Observation: "Recurring charge of $15.99 on the 1st each month (Netflix)"
Proposed Event:
  type: "financial"
  title: "Netflix subscription"
  due_date: "2026-08-01"  (next month)
  recurrence: { pattern: "monthly", day_of_month: 1 }
  financial_impact: -1599
  confidence: 0.88
  source: "derived_from_bank"
  related_memory_ids: ["bill-netflix"]
  
User prompt: "Perch detected a monthly subscription. Track this?"
  [Yes] → Added to financial Events
  [No] → Dismissed; if seen again, confidence drops (0.75)
```

**3. Email & Calendar Imports**
```
Observation: Email contains "Meeting with Jeff, Thursday 2 PM"
Parsed Event:
  type: "appointment"
  title: "Meeting with Jeff"
  due_date: "2026-07-18"
  time_of_day: "14:00"
  confidence: 0.85
  source: "email_parsed"
  related_memory_ids: ["email-id-123"]
  related_person_ids: ["person-jeff"]
  
User action: Event auto-surfaces in calendar preview; no prompt needed
```

**4. Behavior & Habit Patterns**
```
Observation: "You go to the gym on Monday, Wednesday, Friday around 6 PM (12+ times)"
Proposed Event:
  type: "habit" / "recurring_event"
  title: "Gym session"
  recurrence: { pattern: "weekly", days: [1,3,5] }  // MWF
  time_of_day: "18:00"
  confidence: 0.82
  source: "pattern_detected"
  
User prompt: "Perch noticed you work out regularly. Track as habit?"
  [Yes] → Added as recurring; can serve notifications
  [No] → Not displayed, but pattern remains observable
```

**5. Living World & Weather Predictions**
```
Observation: "Clear weather Tuesday + lawn hasn't been mowed in 22 days"
Proposed Event:
  type: "opportunity"
  title: "Good day to mow lawn"
  due_date: "2026-07-14"  (Tuesday)
  confidence: 0.68
  source: "ai_suggested"
  metadata:
    opportunity_type: "weather_window"
    signals: ["clear_forecast", "lawn_overdue", "free_schedule"]
  
User prompt: "Tuesday looks like a perfect day to mow. Want a reminder?"
  [Yes] → Marked as Opportunity Event
  [No] → Dismissed; similar suggestions reduced in frequency
```

**6. Goal Milestones & Deadlines**
```
Observation: "You want to save $5000 for a trip by Oct 1. That's 12 weeks.
              At your current saving rate ($300/month), you'll hit $5400."
Proposed Event:
  type: "milestone"
  title: "Yellowstone trip savings: On track!"
  due_date: "2026-10-01"
  confidence: 0.75
  source: "ai_suggested"
  goal_connection: ["goal-yellowstone"]
  metadata:
    projection: "At current pace, you'll have $5400 by target date"

User prompt: "You're on track for your Yellowstone trip savings goal!"
  (No action needed; informational)
```

### 5.2 Confidence Decay & Learning

AI-generated Events start with medium confidence and evolve:

```
AI-Suggested Event lifecycle:

1. Initial: confidence = 0.65 (medium)
   - AI-generated; not user-confirmed
   - Appears in Suggestions surface
   - No notification yet

2. After user accepts: confidence → 0.85
   - User explicitly said "yes, track this"
   - Now surfaces like user-created Events
   - Notification enabled

3. After user dismisses repeatedly: confidence → 0.40, then archived
   - User said "no" multiple times
   - System learns: "User doesn't value this type of suggestion"
   - Confidence decays; similar future suggestions are less likely

4. After user acts on it: confidence → 0.92
   - User completed the suggested Event
   - Behavior matches AI prediction
   - System learns: "This AI suggestion was valuable"
   - Higher confidence for similar future suggestions

5. After long consistency: confidence → 1.0 (or 0.95 practical max)
   - Pattern holds for 12+ months
   - AI prediction was accurate
   - System treats AI-created Event like user fact
```

### 5.3 Constraints to Avoid Spam

**Rule 1: Minimum confidence before surfacing**
- Never propose an Event with confidence < 0.45 to user.
- Keep low-confidence suggestions searchable but hidden.

**Rule 2: Batching**
- If AI detects 5 patterns in one day, bundle into one Suggestions digest.
- Never send 5 individual prompts.

**Rule 3: Frequency caps**
- "Mow lawn" suggestion: max 1 per week, even if weather is consistently good.
- "Call Mom" suggestion: max 1 per month.

**Rule 4: User preference learning**
- If user dismisses "exercise suggestions" repeatedly: reduce frequency by 80%.
- If user accepts "money-saving suggestions": increase frequency by 50%.

**Rule 5: Context-aware timing**
- Don't suggest "weekend project" on a busy weekday.
- Don't suggest "relaxation" when user is rushing.

---

## 6. Notification System Integration

Notifications are the bridge between Events and user awareness.

### 6.1 Notification Strategies per Event Type

| Event Type | Notify Strategy | Advance Hours | Example |
|---|---|---|---|
| Financial (bill) | alert | 72 | "Duke Energy due in 3 days" |
| Financial (paycheck) | digest | 24 | Daily money digest |
| Appointment | alert | 24 | "Dentist appt tomorrow at 2 PM" |
| Deadline | priority_alert | varies | Escalates as deadline nears |
| Habit | silent | — | Visible in calendar; no alarm |
| Opportunity | digest | 24 | Weekly opportunities digest |
| Milestone | digest | 24 | "Mom's birthday is this weekend" |
| Maintenance | digest | varies | Monthly maintenance reminder |
| Health | alert | 24–48 | Prescription refills |
| AI suggestion | digest | 24 | "You found 3 patterns this week" |

### 6.2 Smart Batching

```
Multiple Events, one notification:

Multiple bills this week:
  Duke Energy (Tue, $125)
  Internet (Wed, $60)
  Mortgage (Fri, $1200)
  
Batched notification (one message):
  "3 bills this week: $1,385 total
   - Duke Energy: $125 (Tue)
   - Internet: $60 (Wed)
   - Mortgage: $1,200 (Fri)"

Multiple habits this week:
  Gym: 3/7 days
  Meditation: 2/7 days
  Read: 1/7 days
  
Weekly digest (one message):
  "This week's habits:
   - Gym: 3 sessions ✓
   - Meditation: 2 sessions
   - Read: 1 session (need more?)"
```

### 6.3 Suppression & Preferences

User can suppress notifications by:
- **Type**: "No bill reminders; only alerts for overdue"
- **Time**: "No notifications between 9 PM and 7 AM"
- **Surface**: "Suppress notifications for optional items"
- **Category**: "No health reminders during work week"
- **Urgency**: "Only critical alerts; no routine reminders"

---

## 7. Widget Consumption

Widgets are UI components that consume Event data.

### 7.1 Widget ← Event Flow

```
Today Widget:
  1. Query Events: status IN (active, urgent), due_date = today
  2. Sort by priority_score DESC
  3. Take top 1
  4. Pass to Voice Engine
  5. Render phrased text + actions
  
Week Widget:
  1. Query Events: due_date IN [today, today+7]
  2. Sort by due_date ASC, priority_score DESC
  3. Group by day
  4. Render timeline

Bills Widget:
  1. Query Events: category = "financial"
  2. Sort by due_date ASC
  3. Sum financial_impact
  4. Render: "3 bills due this month: $1,200"
  
Opportunities Widget:
  1. Query Events: type = "opportunity", status = "upcoming"
  2. Sort by priority_score DESC
  3. Render: "3 good opportunities this week"
```

### 7.2 Example: Today Widget Processing

```
App loads → Today Widget triggers:

1. Fetch Events:
   SELECT * FROM perch_events
   WHERE status IN ('active', 'urgent')
     AND due_date = TODAY()
     AND completion_state = 'incomplete'
   ORDER BY priority_score DESC, due_date ASC

2. Results:
   - Duke Energy bill (priority: 100)
   - Gym session (priority: 75)
   - Mom's call (priority: 65)

3. Select top 1:
   Duke Energy bill

4. Pass to Voice Engine:
   Event {
     type: "financial",
     title: "Duke Energy",
     due_date: TODAY(),
     confidence: 1.0,
     financial_impact: -12500
   }

5. Voice Engine returns:
   "Duke Energy bill is due today. ($125.42)"

6. Design layer adds:
   highlight_level: "normal"
   color: "neutral"
   icon: "bill"

7. Render to page:
   ┌─────────────────────────────┐
   │ Thursday                    │
   │ Today is the last day.      │  (Hero line: observational)
   │                             │
   │ Duke Energy                 │  (One thing title)
   │ This is due today.          │  (Voice-phrased)
   │ [Done] [Later]              │  (Actions)
   └─────────────────────────────┘
```

---

## 8. Voice Engine Integration

Events are phrased by the Voice Engine per tone rules (Chapter 11).

### 8.1 Voice Receives Event Properties

```
Voice Engine input:
  Event {
    title: "Duke Energy",
    type: "financial",
    due_date: 2026-07-09,
    days_until: 1,
    confidence: 1.0,
    importance: 0.95,
    financial_impact: -12500,
    category: "financial"
  }

Voice rules (per perch_truth.md):
  1. Confidence check: 1.0 → declarative tone OK
  2. Type check: financial → straightforward, no inflection
  3. Importance check: 0.95 → this matters; acknowledge it
  4. Time check: 1 day → urgency is real

Voice output (multiple tones):
  Factual: "Duke Energy bill is due tomorrow."
  Empathetic: "Money's tight—Duke Energy is due tomorrow."
  Observational: "Another bill lands tomorrow."
  Motivational: "You've got this—Duke Energy lands tomorrow."

Today context: → User's life is under money pressure (money_thin flag)
               → Empathetic tone chosen
  
Rendered: "Money's thin till payday. Duke Energy lands tomorrow."
```

### 8.2 Voice Rules Applied to Events

All of Chapter 11 (Voice Engine) applies:

- **Overdue Events**: "Your bill is overdue by 2 days" (fact), never a reprimand.
- **Urgent vs. Upcoming**: Urgent gets action phrasing; upcoming gets informational.
- **Confidence uncertainty**: Phrased as "likely," "may," "could" per confidence level.
- **Health claims**: Downgrade or avoid medical phrasing (Perch is not a doctor).
- **Financial sensitivity**: No shame language; no guilt-tripping.

---

## 9. Summary: Data Flow

```
┌──────────────────┐
│  SOURCES         │
├──────────────────┤
│ User input       │
│ Calendar import  │
│ Bill data        │
│ Email parser     │
│ Patterns         │
│ Predictions      │
└────────┬─────────┘
         │
         ▼
┌──────────────────┐
│  EVENT CREATION  │ (EVENT_SYSTEM.md §4)
└────────┬─────────┘
         │
         ▼
┌──────────────────┐
│  TRUTH GATING    │ (Integration §3)
└────────┬─────────┘
         │
         ▼
┌──────────────────┐
│  PRIORITY SCORE  │ (Integration §2)
└────────┬─────────┘
         │
    ┌────┴────┬───────┬──────────┐
    ▼         ▼       ▼          ▼
  Today      Money   Week     Widgets
   Page      Page    Page    (Consume)
    │         │       │          │
    └────────┬┴───────┴──────────┘
             │
             ▼
        ┌─────────────┐
        │ VOICE ENGINE│ (Phrase)
        └─────────────┘
             │
             ▼
        ┌──────────────────┐
        │  NOTIFICATION    │ (Deliver)
        │  SYSTEM          │
        └──────────────────┘
             │
             ▼
        ┌──────────────────┐
        │  USER            │
        │  Sees/acts on    │
        │  Event           │
        └──────────────────┘
             │
             ▼
        ┌──────────────────┐
        │  BELIEF ENGINE   │ (Learn)
        │  (Future)        │
        └──────────────────┘
```

This integrated architecture ensures Events flow predictably through all layers of Perch, with consistent Truth gating, priority scoring, phrasing, and feedback loops.
