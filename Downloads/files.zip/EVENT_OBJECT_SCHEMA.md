# Event Object Schema

Complete JSON schema specification for the Perch Event System v1 object model.

## TypeScript Interface (Reference)

```typescript
interface PerchEvent {
  // ========== Identity & Metadata (immutable except updated_at) ==========
  id: string;                        // UUID v4, e.g., "evt-a1b2c3d4-e5f6..."
  type: EventType;                   // See EventType enum
  category: EventCategory;           // See EventCategory enum
  status: EventStatus;               // See EventStatus enum
  source: EventSource;               // See EventSource enum
  created_at: ISO8601DateTime;       // immutable
  updated_at: ISO8601DateTime;       // updated on every field change
  user_created: boolean;             // immutable; true if user explicitly created
  ai_generated: boolean;             // immutable; true if AI system created
  metadata: Record<string, unknown>; // Free-form extensibility

  tags: string[];                    // ["high-priority", "recurring", ...]

  // ========== Temporal Dimensions ==========
  due_date: ISO8601Date | null;           // When this Event becomes/became urgent
  start_date: ISO8601Date | null;         // When this Event becomes relevant
  end_date: ISO8601Date | null;           // When this Event is no longer relevant
  all_day: boolean;                       // true if not time-of-day specific (default: false)
  time_of_day: HHMMString | null;         // "14:30" format, if applicable
  timezone: IANATimezoneString | null;    // "America/New_York", etc. (null = device local)
  
  recurrence: RecurrenceRule | null;      // Structured recurrence pattern
  recurrence_end_date: ISO8601Date | null;  // Last date recurrence should occur
  recurrence_exceptions: ISO8601Date[];   // Dates on which recurring Event should NOT occur
  time_sensitivity: TimeSensitivity;      // "immediate" | "urgent" | "soon" | "flexible" | "none"

  // ========== Relationship to User's Life ==========
  importance: number;                // 0–1 (0 = optional, 1 = critical)
  priority_score: number;            // 0–100 (computed, mutable, recalculated per session)
  confidence: number;                // 0–1 (how certain is this Event?)
  health_impact: number | null;      // 0–1 (health-related impact)
  financial_impact: number | null;   // Amount in cents (can be negative for cost)
  relationship_impact: string[] | null;  // Array of person IDs
  goal_connection: string[] | null;  // Array of goal IDs
  life_priority_rank: number | null; // 1–5 (user's life priority alignment)

  // ========== Status & Completion ==========
  completion_state: CompletionState; // See CompletionState enum
  completed_at: ISO8601DateTime | null;
  completion_notes: string | null;
  snoozed_until: ISO8601DateTime | null;
  deferred_to_date: ISO8601Date | null;

  // ========== Hierarchy & Relationships ==========
  parent_event_id: string | null;        // If child of recurring Event
  child_events: string[];                // IDs of generated children (if recurring)
  related_event_ids: string[];           // Semantically related Events
  related_memory_ids: string[];          // Memory/capture IDs
  related_person_ids: string[];          // Person IDs

  // ========== Notification & Surface Control ==========
  notify: NotificationStrategy;      // "silent" | "digest" | "alert" | "priority_alert"
  notify_advance_hours: number | null; // Hours before due_date to notify
  suppress_on_surfaces: string[];    // Surfaces where this Event should NOT appear
  highlight_level: HighlightLevel;   // "minimal" | "normal" | "prominent" | "critical"
}

// ========== Enums ==========

enum EventType {
  reminder = "reminder",
  deadline = "deadline",
  appointment = "appointment",
  maintenance = "maintenance",
  financial = "financial",
  habit = "habit",
  goal = "goal",
  milestone = "milestone",
  notification = "notification",
  alert = "alert",
  opportunity = "opportunity",
  recurring_event = "recurring_event",
  suggested_event = "suggested_event",
  system_event = "system_event",
  external_event = "external_event",
}

enum EventCategory {
  financial = "financial",
  health = "health",
  family = "family",
  work = "work",
  home = "home",
  project = "project",
  learning = "learning",
  personal = "personal",
  travel = "travel",
  social = "social",
  other = "other",
}

enum EventStatus {
  created = "created",
  scheduled = "scheduled",
  active = "active",
  upcoming = "upcoming",
  urgent = "urgent",
  completed = "completed",
  cancelled = "cancelled",
  expired = "expired",
  archived = "archived",
}

enum EventSource {
  user_created = "user_created",
  imported_calendar = "imported_calendar",
  derived_from_bill = "derived_from_bill",
  ai_suggested = "ai_suggested",
  pattern_detected = "pattern_detected",
  email_parsed = "email_parsed",
  api_ingested = "api_ingested",
  prediction = "prediction",
  system_generated = "system_generated",
}

enum CompletionState {
  incomplete = "incomplete",
  completed = "completed",
  skipped = "skipped",
  dismissed = "dismissed",
  snoozed = "snoozed",
  deferred = "deferred",
  cancelled = "cancelled",
  expired = "expired",
}

enum TimeSensitivity {
  immediate = "immediate",    // minutes to hours
  urgent = "urgent",          // hours to days
  soon = "soon",              // days to weeks
  flexible = "flexible",      // weeks+
  none = "none",              // time-insensitive
}

enum NotificationStrategy {
  silent = "silent",
  digest = "digest",
  alert = "alert",
  priority_alert = "priority_alert",
}

enum HighlightLevel {
  minimal = "minimal",
  normal = "normal",
  prominent = "prominent",
  critical = "critical",
}

interface RecurrenceRule {
  pattern: "daily" | "weekly" | "monthly" | "yearly";
  interval: number;           // e.g., 1 = every day, 2 = every 2 days, etc.
  days?: number[];            // For weekly: [0=Sun, 1=Mon, ..., 6=Sat]
  day_of_month?: number;      // For monthly: 1–31
  day_of_week?: number;       // For monthly: 0–6 (0=Sun)
  week_of_month?: number;     // For monthly: 1–5 (1st through 5th)
}

type ISO8601DateTime = string;    // "2026-07-10T14:30:00Z"
type ISO8601Date = string;        // "2026-07-10"
type HHMMString = string;         // "14:30"
type IANATimezoneString = string; // "America/New_York"
```

## JSON Example: Full Event

```json
{
  "id": "evt-f8a2c1d0-9e5b-4f3d-a2b1-7c9d8e6f5a4b",
  "type": "financial",
  "category": "financial",
  "status": "active",
  "source": "user_created",
  "created_at": "2026-03-15T09:00:00Z",
  "updated_at": "2026-07-01T14:30:00Z",
  "user_created": true,
  "ai_generated": false,
  "metadata": {
    "provider": "Duke Energy",
    "account_number": "1234567890",
    "recurring_template_id": "bill-duke-energy-monthly"
  },
  "tags": ["recurring", "monthly", "utility"],

  "due_date": "2026-07-15",
  "start_date": "2026-07-01",
  "end_date": null,
  "all_day": true,
  "time_of_day": null,
  "timezone": null,
  
  "recurrence": {
    "pattern": "monthly",
    "interval": 1,
    "day_of_month": 15
  },
  "recurrence_end_date": null,
  "recurrence_exceptions": [],
  "time_sensitivity": "urgent",

  "importance": 0.95,
  "priority_score": 87,
  "confidence": 1.0,
  "health_impact": null,
  "financial_impact": -12500,
  "relationship_impact": null,
  "goal_connection": ["goal-emergency-fund"],
  "life_priority_rank": 1,

  "completion_state": "incomplete",
  "completed_at": null,
  "completion_notes": null,
  "snoozed_until": null,
  "deferred_to_date": null,

  "parent_event_id": "evt-f8a2c1d0-9e5b-recurring-duke-energy",
  "child_events": [],
  "related_event_ids": ["evt-other-utility-bills"],
  "related_memory_ids": ["capture-duke-energy-account"],
  "related_person_ids": null,

  "notify": "alert",
  "notify_advance_hours": 72,
  "suppress_on_surfaces": [],
  "highlight_level": "normal"
}
```

## JSON Example: AI-Suggested Event

```json
{
  "id": "evt-a4b5c6d7-e8f9-4a0b-1c2d-3e4f5a6b7c8d",
  "type": "suggested_event",
  "category": "home",
  "status": "created",
  "source": "ai_suggested",
  "created_at": "2026-07-08T10:15:00Z",
  "updated_at": "2026-07-08T10:15:00Z",
  "user_created": false,
  "ai_generated": true,
  "metadata": {
    "confidence_reason": "Clear weather window + 3-week grass growth pattern + user's schedule flexibility",
    "source_signals": ["weather_forecast", "lawn_growth_detection", "calendar_free_time"],
    "suggestion_score": 0.72
  },
  "tags": ["ai-suggestion", "maintenance", "optional"],

  "due_date": "2026-07-14",
  "start_date": null,
  "end_date": null,
  "all_day": true,
  "time_of_day": null,
  "timezone": null,
  
  "recurrence": null,
  "recurrence_end_date": null,
  "recurrence_exceptions": [],
  "time_sensitivity": "flexible",

  "importance": 0.45,
  "priority_score": 42,
  "confidence": 0.68,
  "health_impact": 0.3,
  "financial_impact": null,
  "relationship_impact": ["person-family-unit"],
  "goal_connection": ["goal-homestead-maintenance"],
  "life_priority_rank": 4,

  "completion_state": "incomplete",
  "completed_at": null,
  "completion_notes": null,
  "snoozed_until": null,
  "deferred_to_date": null,

  "parent_event_id": null,
  "child_events": [],
  "related_event_ids": [],
  "related_memory_ids": ["capture-lawn-maintenance-notes"],
  "related_person_ids": ["person-family-unit"],

  "notify": "digest",
  "notify_advance_hours": 24,
  "suppress_on_surfaces": ["today_note"],
  "highlight_level": "minimal"
}
```

## JSON Example: Recurring Event Template

```json
{
  "id": "evt-recurring-weekly-gym",
  "type": "recurring_event",
  "category": "health",
  "status": "scheduled",
  "source": "user_created",
  "created_at": "2026-01-02T08:00:00Z",
  "updated_at": "2026-07-01T10:00:00Z",
  "user_created": true,
  "ai_generated": false,
  "metadata": {
    "friendly_name": "Weekly gym session",
    "gym_location": "24 Hour Fitness, downtown"
  },
  "tags": ["recurring", "habit", "health", "weekly"],

  "due_date": null,
  "start_date": "2026-01-02",
  "end_date": null,
  "all_day": false,
  "time_of_day": "18:00",
  "timezone": "America/New_York",
  
  "recurrence": {
    "pattern": "weekly",
    "interval": 1,
    "days": [1, 3, 5]
  },
  "recurrence_end_date": null,
  "recurrence_exceptions": ["2026-07-04", "2026-12-25"],
  "time_sensitivity": "flexible",

  "importance": 0.65,
  "priority_score": null,
  "confidence": 0.9,
  "health_impact": 0.8,
  "financial_impact": null,
  "relationship_impact": null,
  "goal_connection": ["goal-fitness-improve"],
  "life_priority_rank": 3,

  "completion_state": "incomplete",
  "completed_at": null,
  "completion_notes": null,
  "snoozed_until": null,
  "deferred_to_date": null,

  "parent_event_id": null,
  "child_events": [
    "evt-gym-2026-07-08",
    "evt-gym-2026-07-10",
    "evt-gym-2026-07-15",
    "evt-gym-2026-07-17",
    "evt-gym-2026-07-22",
    "evt-gym-2026-07-24"
  ],
  "related_event_ids": [],
  "related_memory_ids": ["capture-fitness-routine"],
  "related_person_ids": null,

  "notify": "silent",
  "notify_advance_hours": null,
  "suppress_on_surfaces": [],
  "highlight_level": "normal"
}
```

## JSON Example: Child Event (from Recurrence)

```json
{
  "id": "evt-gym-2026-07-08",
  "type": "habit",
  "category": "health",
  "status": "upcoming",
  "source": "pattern_detected",
  "created_at": "2026-07-01T10:00:00Z",
  "updated_at": "2026-07-01T10:00:00Z",
  "user_created": false,
  "ai_generated": false,
  "metadata": {
    "source": "generated from recurring template"
  },
  "tags": ["recurring-child", "habit", "health", "wednesday"],

  "due_date": "2026-07-08",
  "start_date": "2026-07-08",
  "end_date": "2026-07-08",
  "all_day": false,
  "time_of_day": "18:00",
  "timezone": "America/New_York",
  
  "recurrence": null,
  "recurrence_end_date": null,
  "recurrence_exceptions": [],
  "time_sensitivity": "flexible",

  "importance": 0.65,
  "priority_score": 38,
  "confidence": 0.9,
  "health_impact": 0.8,
  "financial_impact": null,
  "relationship_impact": null,
  "goal_connection": ["goal-fitness-improve"],
  "life_priority_rank": 3,

  "completion_state": "incomplete",
  "completed_at": null,
  "completion_notes": null,
  "snoozed_until": null,
  "deferred_to_date": null,

  "parent_event_id": "evt-recurring-weekly-gym",
  "child_events": [],
  "related_event_ids": [],
  "related_memory_ids": ["capture-fitness-routine"],
  "related_person_ids": null,

  "notify": "silent",
  "notify_advance_hours": null,
  "suppress_on_surfaces": [],
  "highlight_level": "normal"
}
```

## Database Schema (SQLite Reference)

```sql
-- Main events table
CREATE TABLE perch_events (
  id TEXT PRIMARY KEY,
  type TEXT NOT NULL,
  category TEXT NOT NULL,
  status TEXT NOT NULL,
  source TEXT NOT NULL,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  
  user_created BOOLEAN NOT NULL DEFAULT 0,
  ai_generated BOOLEAN NOT NULL DEFAULT 0,
  tags TEXT,  -- JSON array, e.g., '["recurring","high-priority"]'
  metadata TEXT,  -- JSON object
  
  due_date TEXT,
  start_date TEXT,
  end_date TEXT,
  all_day BOOLEAN NOT NULL DEFAULT 0,
  time_of_day TEXT,
  timezone TEXT,
  
  recurrence TEXT,  -- JSON object
  recurrence_end_date TEXT,
  recurrence_exceptions TEXT,  -- JSON array
  time_sensitivity TEXT NOT NULL DEFAULT 'flexible',
  
  importance REAL NOT NULL DEFAULT 0.5,
  priority_score REAL,
  confidence REAL NOT NULL DEFAULT 0.5,
  health_impact REAL,
  financial_impact INTEGER,
  relationship_impact TEXT,  -- JSON array of person IDs
  goal_connection TEXT,  -- JSON array of goal IDs
  life_priority_rank INTEGER,
  
  completion_state TEXT NOT NULL DEFAULT 'incomplete',
  completed_at TEXT,
  completion_notes TEXT,
  snoozed_until TEXT,
  deferred_to_date TEXT,
  
  parent_event_id TEXT,
  child_events TEXT,  -- JSON array
  related_event_ids TEXT,  -- JSON array
  related_memory_ids TEXT,  -- JSON array
  related_person_ids TEXT,  -- JSON array
  
  notify TEXT NOT NULL DEFAULT 'digest',
  notify_advance_hours INTEGER,
  suppress_on_surfaces TEXT,  -- JSON array
  highlight_level TEXT NOT NULL DEFAULT 'normal',
  
  FOREIGN KEY (parent_event_id) REFERENCES perch_events(id)
);

-- Indexes for performance
CREATE INDEX idx_perch_events_due_date ON perch_events(due_date);
CREATE INDEX idx_perch_events_status ON perch_events(status);
CREATE INDEX idx_perch_events_category ON perch_events(category);
CREATE INDEX idx_perch_events_priority_score ON perch_events(priority_score DESC);
CREATE INDEX idx_perch_events_created_at ON perch_events(created_at DESC);

-- Archive table (same schema, for completed/expired events >30 days old)
CREATE TABLE perch_events_archive (
  -- Same schema as perch_events
  -- ... (truncated)
);

-- Materialized view: active and upcoming events (refreshed every load)
CREATE VIEW perch_events_active AS
SELECT *
FROM perch_events
WHERE status IN ('created', 'scheduled', 'active', 'upcoming', 'urgent')
  AND due_date IS NOT NULL
  AND completion_state = 'incomplete'
ORDER BY due_date ASC, priority_score DESC;
```

## Validation & Constraints

### Required Fields (on creation)

- `type` (must be valid EventType)
- `category` (must be valid EventCategory)
- `status` (defaults to "created")
- `source` (must be valid EventSource)
- `importance` (defaults to 0.5)
- `confidence` (defaults to 0.5)

### Mutable Fields

All fields except: `id`, `type`, `source`, `created_at`, `user_created`, `ai_generated`, `parent_event_id`

### Field Constraints

- `importance`: 0.0 ≤ value ≤ 1.0
- `confidence`: 0.0 ≤ value ≤ 1.0
- `priority_score`: 0 ≤ value ≤ 100
- `financial_impact`: can be negative (cost) or positive (income)
- `health_impact`: 0.0 ≤ value ≤ 1.0 (if not null)
- `life_priority_rank`: 1 ≤ value ≤ 5 (if not null)
- `notify_advance_hours`: must be positive if set
- If `recurrence` is not null, `pattern` must be "daily", "weekly", "monthly", or "yearly"
- If `due_date` is null, `time_sensitivity` should be "none" or "flexible"

### Lifecycle Constraints

- Event cannot move from `archived` to any non-archived state.
- Event cannot be marked `completed` if `status = "created"` (must be scheduled first).
- If `completion_state = "incomplete"`, then `completed_at` must be null.
- If `snoozed_until` is set, `status` is marked "snoozed" (special transient state).
- If `recurrence` is not null, the Event is a template; `child_events[]` is managed by the system.

---

## Query Patterns & Examples

### Query: Get all financial Events due in the next 7 days

```sql
SELECT * FROM perch_events
WHERE category = 'financial'
  AND due_date >= date('now')
  AND due_date <= date('now', '+7 days')
  AND status IN ('scheduled', 'active', 'upcoming', 'urgent')
  AND completion_state = 'incomplete'
ORDER BY due_date ASC, priority_score DESC;
```

### Query: Get top 5 Events by priority for Today's note

```sql
SELECT * FROM perch_events_active
WHERE status IN ('active', 'urgent')
  AND due_date = date('now')
ORDER BY priority_score DESC
LIMIT 5;
```

### Query: Find all upcoming recurring Events

```sql
SELECT * FROM perch_events
WHERE recurrence IS NOT NULL
  AND status IN ('scheduled', 'upcoming')
  AND completion_state = 'incomplete'
ORDER BY due_date ASC;
```

### Query: Search for Events related to a specific goal

```sql
SELECT * FROM perch_events
WHERE goal_connection LIKE '%goal-emergency-fund%'
  AND completion_state = 'incomplete'
ORDER BY priority_score DESC;
```

---

This schema is designed for:
- **Clarity**: Every field has a clear purpose and a defined range.
- **Extensibility**: `metadata` object allows ad-hoc fields without schema changes.
- **Performance**: Indexed queries on common axes (date, status, priority).
- **Compatibility**: JSON fields store complex data (arrays, objects) in SQLite without advanced features.
- **Immutability**: Audit trail is preserved; mutable fields are distinct; creation/update timestamps track history.
